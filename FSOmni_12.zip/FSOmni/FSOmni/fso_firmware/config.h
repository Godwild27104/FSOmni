// ================================================================
// config.h — Configuration pour l'ÉTAPE 1
// ================================================================

#ifndef CONFIG_H
#define CONFIG_H

// Configuration WiFi Access Point
#define WIFI_SSID "FSOmni"
#define WIFI_PASSWORD "fsomni2026"
#define WIFI_CHANNEL 6
#define MAX_CLIENTS 4

// Configuration WebSocket
#define WS_PORT 8080

// Configuration Serial Debug
#define SERIAL_BAUD 115200

#endif
