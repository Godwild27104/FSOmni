// ================================================================
// fso_firmware.ino — Firmware principal FSOmni - ÉTAPE 1
// ================================================================
// Ce firmware crée un point d'accès WiFi et un serveur WebSocket
// pour permettre à l'application Android de se connecter.
// ================================================================

#include "config.h"
#include "wifi_ws.h"

// ================================================================
// SETUP — Initialisation du système
// ================================================================
void setup() {
  // Démarrage du Serial Monitor
  Serial.begin(SERIAL_BAUD);
  delay(1000);
  
  Serial.println("========================================");
  Serial.println("  FSOmni Firmware - ÉTAPE 1");
  Serial.println("  WiFi AP + WebSocket");
  Serial.println("========================================");
  
  // Initialisation WiFi et WebSocket
  initWifiWs();
  
  Serial.println("Système prêt");
  Serial.println("========================================");
}

// ================================================================
// LOOP — Boucle principale
// ================================================================
void loop() {
  // Maintenance WebSocket
  wifiWsLoop();
  
  // Délai court
  delay(10);
}
