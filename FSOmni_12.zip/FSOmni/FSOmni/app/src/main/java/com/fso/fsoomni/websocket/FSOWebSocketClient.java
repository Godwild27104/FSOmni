package com.fso.fsoomni.websocket;

import android.util.Log;

import com.fso.fsoomni.model.AppState;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;

public class FSOWebSocketClient {

    private static final String TAG = "FSOWebSocket";
    private static final int DEFAULT_PORT = 8080;

    private WebSocketClient client;
    private final AppState appState;
    private final Gson gson = new Gson();
    private final Map<String, CopyOnWriteArrayList<WebSocketListener>> listeners = new HashMap<>();
    private int reconnectAttempts = 0;
    private static final int MAX_RECONNECT_ATTEMPTS = 6;
    private static final int BASE_RECONNECT_DELAY_MS = 1000;

    public interface WebSocketListener {
        void onMessage(String type, JsonObject data);
        void onConnected();
        void onDisconnected();
        void onError(String error);
    }

    public FSOWebSocketClient(AppState appState) {
        this.appState = appState;
    }

    public void addListener(WebSocketListener listener) {
        addListener("*", listener);
    }

    public void addListener(String eventType, WebSocketListener listener) {
        if (!listeners.containsKey(eventType)) {
            listeners.put(eventType, new CopyOnWriteArrayList<>());
        }
        listeners.get(eventType).add(listener);
    }

    public void removeListener(WebSocketListener listener) {
        for (Map.Entry<String, CopyOnWriteArrayList<WebSocketListener>> entry : listeners.entrySet()) {
            entry.getValue().remove(listener);
        }
    }

    private void notifyMessage(String type, JsonObject data) {
        // Notify wildcard listeners
        if (listeners.containsKey("*")) {
            for (WebSocketListener l : listeners.get("*")) {
                l.onMessage(type, data);
            }
        }
        // Notify specific type listeners
        if (listeners.containsKey(type)) {
            for (WebSocketListener l : listeners.get(type)) {
                l.onMessage(type, data);
            }
        }
    }

    private void notifyConnected() {
        for (CopyOnWriteArrayList<WebSocketListener> list : listeners.values()) {
            for (WebSocketListener l : list) {
                l.onConnected();
            }
        }
    }

    private void notifyDisconnected() {
        for (CopyOnWriteArrayList<WebSocketListener> list : listeners.values()) {
            for (WebSocketListener l : list) {
                l.onDisconnected();
            }
        }
    }

    private void notifyError(String error) {
        for (CopyOnWriteArrayList<WebSocketListener> list : listeners.values()) {
            for (WebSocketListener l : list) {
                l.onError(error);
            }
        }
    }

    public void connect(String ip) {
        disconnect();

        try {
            String url = "ws://" + ip + ":" + DEFAULT_PORT;
            URI uri = new URI(url);
            
            Log.d(TAG, "Attempting WebSocket connection to: " + url);

            client = new WebSocketClient(uri) {
                @Override
                public void onOpen(ServerHandshake handshake) {
                    Log.d(TAG, "✅ WebSocket connected successfully to " + url);
                    Log.d(TAG, "Server handshake: HTTP " + handshake.getHttpStatus() + " - " + handshake.getHttpStatusMessage());
                    reconnectAttempts = 0;
                    appState.setConnected(true);
                    notifyConnected();
                }

                @Override
                public void onMessage(String message) {
                    Log.d(TAG, "📩 Message received: " + message);
                    try {
                        JsonObject json = JsonParser.parseString(message).getAsJsonObject();
                        String type = json.has("type") ? json.get("type").getAsString() : "unknown";
                        processMessage(type, json);
                        notifyMessage(type, json);
                    } catch (Exception e) {
                        Log.e(TAG, "❌ Error parsing message: " + e.getMessage(), e);
                    }
                }

                @Override
                public void onClose(int code, String reason, boolean remote) {
                    String remoteStr = remote ? "remote" : "local";
                    Log.d(TAG, "🔌 WebSocket closed (" + remoteStr + "). Code: " + code + ", Reason: " + reason);
                    appState.setConnected(false);
                    notifyDisconnected();
                    
                    // Only attempt reconnect if closed by remote
                    if (remote && reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
                        attemptReconnect(ip);
                    }
                }

                @Override
                public void onError(Exception ex) {
                    Log.e(TAG, "❌ WebSocket error: " + ex.getMessage(), ex);
                    appState.setConnected(false);
                    
                    String errorMsg = ex.getMessage();
                    if (errorMsg == null) {
                        errorMsg = "Erreur de connexion inconnue";
                    } else if (errorMsg.contains("failed to connect")) {
                        errorMsg = "Impossible de se connecter au serveur";
                    } else if (errorMsg.contains("Connection refused")) {
                        errorMsg = "Connexion refusée - Vérifiez que le serveur est démarré";
                    } else if (errorMsg.contains("timeout")) {
                        errorMsg = "Timeout - Le serveur ne répond pas";
                    } else if (errorMsg.contains("Network is unreachable")) {
                        errorMsg = "Réseau inaccessible - Vérifiez votre connexion WiFi";
                    }
                    
                    notifyError(errorMsg);
                }
            };

            client.setConnectionLostTimeout(10); // 10 seconds timeout
            
            // Connect in background thread
            new Thread(() -> {
                try {
                    Log.d(TAG, "🔄 Starting WebSocket connection in background thread...");
                    boolean connected = client.connectBlocking();
                    if (!connected) {
                        Log.e(TAG, "❌ WebSocket connectBlocking returned false");
                        notifyError("Échec de la connexion au serveur WebSocket");
                    }
                } catch (Exception e) {
                    Log.e(TAG, "❌ Exception during connectBlocking: " + e.getMessage(), e);
                    notifyError("Erreur : " + e.getMessage());
                }
            }).start();

        } catch (Exception e) {
            Log.e(TAG, "❌ Failed to initialize WebSocket connection: " + e.getMessage(), e);
            notifyError("Erreur d'initialisation : " + e.getMessage());
        }
    }

    public void disconnect() {
        if (client != null) {
            client.close();
            client = null;
        }
        appState.setConnected(false);
        reconnectAttempts = 0;
    }

    private void attemptReconnect(String ip) {
        if (reconnectAttempts >= MAX_RECONNECT_ATTEMPTS) {
            Log.w(TAG, "Max reconnect attempts reached");
            return;
        }

        int rawDelay = (int) (BASE_RECONNECT_DELAY_MS * Math.pow(2, reconnectAttempts));
        final int delay = Math.min(rawDelay, 30000); // Cap at 30s

        reconnectAttempts++;
        final int attempt = reconnectAttempts;

        new Thread(() -> {
            try {
                Thread.sleep(delay);
                Log.d(TAG, "Reconnect attempt " + attempt + " after " + delay + "ms");
                connect(ip);
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        }).start();
    }

    private void processMessage(String type, JsonObject json) {
        switch (type) {
            case "telemetry":
                if (json.has("throughput")) {
                    appState.setLastThroughput(json.get("throughput").getAsDouble());
                    // Map throughput to bar value (scale 0-20 Mbps to 0-100)
                    int barVal = (int) Math.min(100, Math.max(0, (json.get("throughput").getAsDouble() / 20.0) * 100));
                    appState.pushBarValue(barVal);
                }
                if (json.has("ber")) {
                    appState.setLastBer(json.get("ber").getAsDouble());
                }
                if (json.has("rssi")) {
                    appState.setLastRssi(json.get("rssi").getAsDouble());
                }
                if (json.has("alignment_precision")) {
                    appState.setLastAlignmentPrecision(json.get("alignment_precision").getAsDouble());
                }
                break;

            case "weather":
                if (json.has("visibility")) {
                    appState.setLastVisibility(json.get("visibility").getAsDouble());
                }
                if (json.has("attenuation")) {
                    appState.setLastAttenuation(json.get("attenuation").getAsDouble());
                }
                if (json.has("humidity")) {
                    appState.setLastHumidity(json.get("humidity").getAsDouble());
                }
                break;

            case "alignment":
                if (json.has("tilt")) {
                    appState.setServoTilt(json.get("tilt").getAsDouble());
                }
                break;

            case "esp_status":
                if (json.has("temp")) {
                    appState.setEspTemp(json.get("temp").getAsDouble());
                }
                if (json.has("etat")) {
                    appState.setEspEtat(json.get("etat").getAsDouble());
                }
                if (json.has("uptime")) {
                    appState.setEspUptime(json.get("uptime").getAsString());
                }
                break;

            case "channel_status":
                if (json.has("ch1")) {
                    appState.setCh1Status(json.get("ch1").getAsString());
                }
                if (json.has("ch2")) {
                    appState.setCh2Status(json.get("ch2").getAsString());
                }
                if (json.has("ch3")) {
                    appState.setCh3Status(json.get("ch3").getAsString());
                }
                break;

            case "log":
                // Log event - can be displayed in settings
                break;

            case "security_alert":
                // Critical alert
                break;
        }
    }

    public void sendMessage(String type, JsonObject payload) {
        if (client != null && client.isOpen()) {
            JsonObject msg = new JsonObject();
            msg.addProperty("type", type);
            if (payload != null) {
                for (Map.Entry<String, com.google.gson.JsonElement> entry : payload.entrySet()) {
                    msg.add(entry.getKey(), entry.getValue());
                }
            }
            client.send(gson.toJson(msg));
        } else {
            Log.w(TAG, "Cannot send message - WebSocket not connected");
        }
    }

    public void sendServoCommand(String axis, double value) {
        JsonObject payload = new JsonObject();
        payload.addProperty("axis", axis);
        payload.addProperty("value", value);
        sendMessage("servo", payload);
    }

    public void sendTinymlCommand(boolean enabled, int sensitivity, int reactivity) {
        JsonObject payload = new JsonObject();
        payload.addProperty("enabled", enabled);
        payload.addProperty("sensitivity", sensitivity);
        payload.addProperty("reactivity", reactivity);
        sendMessage("tinyml", payload);
    }

    public void sendAutoAlignCommand(boolean enabled) {
        JsonObject payload = new JsonObject();
        payload.addProperty("enabled", enabled);
        sendMessage("auto_align", payload);
    }

    public void sendGainCommand(int value) {
        JsonObject payload = new JsonObject();
        payload.addProperty("value", value);
        sendMessage("gain", payload);
    }

    public void sendChatMessage(String text) {
        JsonObject payload = new JsonObject();
        payload.addProperty("text", text);
        sendMessage("msg_out", payload);
    }

    public boolean isConnected() {
        return client != null && client.isOpen();
    }
}
