package com.fso.fsoomni.fragment;

import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.fso.fsoomni.R;
import com.fso.fsoomni.model.AppState;
import com.fso.fsoomni.view.BarChartView;
import com.fso.fsoomni.view.GaugeRingView;

public class DashboardFragment extends Fragment {

    private AppState appState;
    private com.fso.fsoomni.websocket.FSOWebSocketClient wsClient;
    private Handler handler = new Handler(Looper.getMainLooper());

    private TextView throughputValue;
    private BarChartView throughputChart;
    private TextView berValue;
    private GaugeRingView alignmentGauge;
    private TextView rssiValue;
    private View rssiProgress;
    private TextView weatherVisibility;
    private TextView weatherAttenuation;
    private TextView weatherHumidity;
    private View statusPillDot;
    private TextView statusPillText;
    private View statusPill;
    private View criticalAlertCard;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getActivity() != null) {
            appState = ((com.fso.fsoomni.activity.MainActivity) getActivity()).getAppState();
            wsClient = ((com.fso.fsoomni.activity.MainActivity) getActivity()).getWsClient();
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dashboard, container, false);

        throughputValue = view.findViewById(R.id.throughput_value);
        throughputChart = view.findViewById(R.id.throughput_chart);
        berValue = view.findViewById(R.id.ber_value);
        alignmentGauge = view.findViewById(R.id.alignment_gauge);
        rssiValue = view.findViewById(R.id.rssi_value);
        rssiProgress = view.findViewById(R.id.rssi_progress);
        weatherVisibility = view.findViewById(R.id.weather_visibility);
        weatherAttenuation = view.findViewById(R.id.weather_attenuation);
        weatherHumidity = view.findViewById(R.id.weather_humidity);
        statusPillDot = view.findViewById(R.id.status_pill_dot);
        statusPillText = view.findViewById(R.id.status_pill_text);
        statusPill = view.findViewById(R.id.status_pill);
        criticalAlertCard = view.findViewById(R.id.critical_alert_card);

        // Hide critical alert card initially
        if (appState != null && !appState.isConnected()) {
            criticalAlertCard.setVisibility(View.GONE);
        }

        // Disconnect button
        view.findViewById(R.id.btn_disconnect).setOnClickListener(v -> {
            android.util.Log.d("DashboardFragment", "Disconnect button clicked");
            
            // Disconnect WebSocket
            if (wsClient != null) {
                android.util.Log.d("DashboardFragment", "Disconnecting WebSocket...");
                wsClient.disconnect();
            }
            
            // Navigate back to Config screen
            if (getActivity() != null) {
                android.util.Log.d("DashboardFragment", "Navigating to Config screen");
                handler.postDelayed(() -> {
                    ((com.fso.fsoomni.activity.MainActivity) getActivity()).navigateTo(0);
                }, 100); // Small delay to ensure disconnect completes
            }
        });

        // Listen for state changes
        if (appState != null) {
            appState.addOnStateChangeListener((key, value) -> {
                handler.post(() -> updateUI(key, value));
            });
        }

        return view;
    }

    private void updateUI(String key, Object value) {
        if (appState == null) return;

        switch (key) {
            case "connected":
                updateConnectionPill((Boolean) value);
                break;
            case "throughput":
                throughputValue.setText(String.format("%.1f", (Double) value));
                break;
            case "barValues":
                throughputChart.setValues(appState.getBarValues());
                break;
            case "ber":
                berValue.setText(String.format("%.1e", (Double) value));
                break;
            case "rssi": {
                double rssi = (Double) value;
                rssiValue.setText(String.valueOf((int) rssi));
                // RSSI progress: (rssi + 100) * 2 clamped 0-100
                int rssiPercent = (int) Math.max(0, Math.min(100, (rssi + 100) * 2));
                updateProgressWidth(rssiProgress, rssiPercent);
                break;
            }
            case "alignmentPrecision":
                alignmentGauge.setProgress((float) ((Double) value / 100.0));
                break;
            case "visibility":
                weatherVisibility.setText(String.format("%.1f km", (Double) value));
                break;
            case "attenuation":
                weatherAttenuation.setText(String.format("%.1f dB/km", (Double) value));
                break;
            case "humidity":
                weatherHumidity.setText(String.format("%.0f%%", (Double) value));
                break;
        }
    }

    private void updateProgressWidth(View progressView, int percent) {
        if (progressView != null && progressView.getParent() instanceof View) {
            View parent = (View) progressView.getParent();
            int parentWidth = parent.getWidth();
            if (parentWidth > 0) {
                FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) progressView.getLayoutParams();
                params.width = (int) (percent / 100f * parentWidth);
                progressView.setLayoutParams(params);
            }
        }
    }

    private void updateConnectionPill(boolean connected) {
        if (getContext() == null || statusPill == null) return;
        
        int tertiaryColor = getResources().getColor(R.color.tertiary, getContext().getTheme());
        int errorColor = getResources().getColor(R.color.error, getContext().getTheme());

        if (connected) {
            statusPill.setBackgroundResource(R.drawable.bg_status_pill_green);
            statusPillDot.setBackgroundColor(tertiaryColor);
            statusPillText.setText("Connecté");
            statusPillText.setTextColor(tertiaryColor);
            
            // Show critical alert card when connected
            if (criticalAlertCard != null) {
                criticalAlertCard.setVisibility(View.VISIBLE);
            }
        } else {
            statusPill.setBackgroundResource(R.drawable.bg_status_pill_red);
            statusPillDot.setBackgroundColor(errorColor);
            statusPillText.setText("Déconnecté");
            statusPillText.setTextColor(errorColor);
            
            // Hide critical alert card when disconnected
            if (criticalAlertCard != null) {
                criticalAlertCard.setVisibility(View.GONE);
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        // Update initial state
        if (appState != null) {
            updateConnectionPill(appState.isConnected());
            throughputValue.setText(String.format("%.1f", appState.getLastThroughput()));
            berValue.setText(String.format("%.1e", appState.getLastBer()));
            rssiValue.setText(String.valueOf((int) appState.getLastRssi()));
            alignmentGauge.setProgress((float) (appState.getLastAlignmentPrecision() / 100.0));
            weatherVisibility.setText(String.format("%.1f km", appState.getLastVisibility()));
            weatherAttenuation.setText(String.format("%.1f dB/km", appState.getLastAttenuation()));
            weatherHumidity.setText(String.format("%.0f%%", appState.getLastHumidity()));

            // Initialize bar chart after layout
            throughputChart.post(() -> throughputChart.setValues(appState.getBarValues()));
        }
    }
}
