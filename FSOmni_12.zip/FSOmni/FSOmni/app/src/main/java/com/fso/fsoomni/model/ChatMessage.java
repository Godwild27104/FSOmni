package com.fso.fsoomni.model;

public class ChatMessage {

    public enum MessageType {
        INCOMING, OUTGOING
    }

    private MessageType type;
    private String sender;
    private String text;
    private String time;
    private String senderId;

    public ChatMessage(MessageType type, String sender, String text, String time) {
        this.type = type;
        this.sender = sender;
        this.text = text;
        this.time = time;
    }

    public ChatMessage(MessageType type, String text, String time) {
        this.type = type;
        this.text = text;
        this.time = time;
    }

    public MessageType getType() {
        return type;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getText() {
        return text;
    }

    public String getTime() {
        return time;
    }

    public String getSenderId() {
        return senderId;
    }

    public void setSenderId(String senderId) {
        this.senderId = senderId;
    }
}
