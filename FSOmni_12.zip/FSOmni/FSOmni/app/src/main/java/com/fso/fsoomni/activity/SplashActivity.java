package com.fso.fsoomni.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.splashscreen.SplashScreen;

import com.fso.fsoomni.FSOmniApp;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Appliquer le thème AVANT super.onCreate() et AVANT le splash screen
        SharedPreferences prefs = getSharedPreferences(FSOmniApp.PREFS_NAME, MODE_PRIVATE);
        boolean isDark = prefs.getBoolean(FSOmniApp.KEY_DARK_MODE, false);
        
        // Forcer le thème de l'activity selon la préférence
        if (isDark) {
            setTheme(androidx.appcompat.R.style.Theme_AppCompat_DayNight);
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            setTheme(androidx.appcompat.R.style.Theme_AppCompat_Light);
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }

        // Installer le splash screen après avoir appliqué le thème
        SplashScreen splashScreen = SplashScreen.installSplashScreen(this);
        
        super.onCreate(savedInstanceState);

        // Rediriger immédiatement vers MainActivity
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}
