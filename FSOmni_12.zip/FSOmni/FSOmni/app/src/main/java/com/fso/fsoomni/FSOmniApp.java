package com.fso.fsoomni;

import android.app.Application;
import android.content.SharedPreferences;

import androidx.appcompat.app.AppCompatDelegate;

public class FSOmniApp extends Application {

    public static final String PREFS_NAME = "fsoomni_prefs";
    public static final String KEY_DARK_MODE = "dark_mode";
    public static final String KEY_THEME_TRANSITIONING = "theme_transitioning";

    @Override
    public void onCreate() {
        super.onCreate();
        // Apply the persisted theme as early as possible — before any Activity is created.
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean isDark = prefs.getBoolean(KEY_DARK_MODE, false);
        AppCompatDelegate.setDefaultNightMode(
                isDark ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO);
    }
}
