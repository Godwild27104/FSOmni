package com.fso.fsoomni.fragment;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.fso.fsoomni.R;
import com.fso.fsoomni.model.AppState;
import com.fso.fsoomni.view.ToggleSwitchView;
import com.fso.fsoomni.websocket.FSOWebSocketClient;

public class SettingsFragment extends Fragment {

    private AppState appState;
    private FSOWebSocketClient wsClient;
    private Handler handler = new Handler(Looper.getMainLooper());

    private ToggleSwitchView toggleTinyml;
    private SeekBar sliderSensitivity;
    private SeekBar sliderReactivity;
    private TextView sensitivityVal;
    private TextView reactivityVal;
    private TextView espTempValue;
    private TextView espEtatValue;
    private View espTempProgress;
    private View espEtatProgress;
    private TextView uptimeValue;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getActivity() != null) {
            appState = ((com.fso.fsoomni.activity.MainActivity) getActivity()).getAppState();
            wsClient = ((com.fso.fsoomni.activity.MainActivity) getActivity()).getWsClient();
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_settings, container, false);

        toggleTinyml = view.findViewById(R.id.toggle_tinyml);
        sliderSensitivity = view.findViewById(R.id.slider_sensitivity);
        sliderReactivity = view.findViewById(R.id.slider_reactivity);
        sensitivityVal = view.findViewById(R.id.sensitivity_val);
        reactivityVal = view.findViewById(R.id.reactivity_val);
        espTempValue = view.findViewById(R.id.esp_temp_value);
        espEtatValue = view.findViewById(R.id.esp_etat_value);
        espTempProgress = view.findViewById(R.id.esp_temp_progress);
        espEtatProgress = view.findViewById(R.id.esp_etat_progress);
        uptimeValue = view.findViewById(R.id.uptime_value);

        // Initialize toggle
        if (appState != null) {
            toggleTinyml.setChecked(appState.isTinymlEnabled());
        }

        // TinyML toggle
        toggleTinyml.setOnCheckedChangeListener(isChecked -> {
            if (appState != null) {
                appState.setTinymlEnabled(isChecked);
            }
            if (wsClient != null) {
                wsClient.sendTinymlCommand(isChecked,
                        sliderSensitivity.getProgress(),
                        sliderReactivity.getProgress());
            }
        });

        // Sensitivity slider
        sliderSensitivity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                sensitivityVal.setText(progress + "%");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (wsClient != null) {
                    wsClient.sendTinymlCommand(
                            toggleTinyml.isChecked(),
                            sliderSensitivity.getProgress(),
                            sliderReactivity.getProgress());
                }
            }
        });

        // Reactivity slider
        sliderReactivity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                reactivityVal.setText(progress + "ms");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {}

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (wsClient != null) {
                    wsClient.sendTinymlCommand(
                            toggleTinyml.isChecked(),
                            sliderSensitivity.getProgress(),
                            sliderReactivity.getProgress());
                }
            }
        });

        // Connection button -> go to config
        view.findViewById(R.id.btn_connect_system).setOnClickListener(v -> {
            if (getActivity() != null) {
                ((com.fso.fsoomni.activity.MainActivity) getActivity()).navigateTo(0);
            }
        });

        // State listener
        if (appState != null) {
            appState.addOnStateChangeListener((key, value) -> handler.post(() -> {
                switch (key) {
                    case "espTemp": {
                        espTempValue.setText(String.format("%.0f°C", (Double) value));
                        int tempPercent = (int) Math.min(100, (Double) value);
                        View tempParent = (View) espTempProgress.getParent();
                        if (tempParent.getWidth() > 0) {
                            FrameLayout.LayoutParams tempParams = (FrameLayout.LayoutParams) espTempProgress.getLayoutParams();
                            tempParams.width = (int) (tempPercent / 100f * tempParent.getWidth());
                            espTempProgress.setLayoutParams(tempParams);
                        }
                        break;
                    }
                    case "espEtat": {
                        espEtatValue.setText(String.format("%.0f%%", (Double) value));
                        int etatPercent = ((Double) value).intValue();
                        View etatParent = (View) espEtatProgress.getParent();
                        if (etatParent.getWidth() > 0) {
                            FrameLayout.LayoutParams etatParams = (FrameLayout.LayoutParams) espEtatProgress.getLayoutParams();
                            etatParams.width = (int) (etatPercent / 100f * etatParent.getWidth());
                            espEtatProgress.setLayoutParams(etatParams);
                        }
                        break;
                    }
                    case "espUptime":
                        uptimeValue.setText((String) value);
                        break;
                }
            }));
        }

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        if (appState != null) {
            espTempValue.setText(String.format("%.0f°C", appState.getEspTemp()));
            espEtatValue.setText(String.format("%.0f%%", appState.getEspEtat()));
            uptimeValue.setText(appState.getEspUptime());
        }
    }
}
