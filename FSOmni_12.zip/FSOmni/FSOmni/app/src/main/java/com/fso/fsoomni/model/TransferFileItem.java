package com.fso.fsoomni.model;

public class TransferFileItem {

    private String name;
    private String size;
    private boolean success;
    private String statusText;
    private String time;

    public TransferFileItem(String name, String size, boolean success, String statusText, String time) {
        this.name = name;
        this.size = size;
        this.success = success;
        this.statusText = statusText;
        this.time = time;
    }

    public String getName() {
        return name;
    }

    public String getSize() {
        return size;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getStatusText() {
        return statusText;
    }

    public String getTime() {
        return time;
    }
}
