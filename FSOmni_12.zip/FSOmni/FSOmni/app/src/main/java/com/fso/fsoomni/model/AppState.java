package com.fso.fsoomni.model;

import java.util.concurrent.CopyOnWriteArrayList;

public class AppState {

    private boolean connected = false;
    private String ip = "192.168.4.1";
    private double servoTilt = 14.22;
    private boolean tinymlEnabled = true;
    private boolean autoAlignEnabled = true;
    private double lastThroughput = 9.8;
    private double lastBer = 1.2e-9;
    private double lastRssi = -42;
    private double lastAlignmentPrecision = 90.0;
    private double lastVisibility = 12.5;
    private double lastAttenuation = 0.4;
    private double lastHumidity = 45.0;
    private double espTemp = 42.0;
    private double espEtat = 88.0;
    private String espUptime = "12j 04h 22m";
    private double lightIntensity = -18.4;

    // Channel status
    private String ch1Status = "ok";
    private String ch2Status = "ok";
    private String ch3Status = "ok";

    // Bar chart data
    private int[] barValues = {65, 72, 58, 80, 92, 85, 70, 95, 88, 78, 90, 98};

    // Callback for state changes - supports multiple listeners
    public interface OnStateChangeListener {
        void onStateChanged(String key, Object value);
    }

    private final CopyOnWriteArrayList<OnStateChangeListener> listeners = new CopyOnWriteArrayList<>();

    public void addOnStateChangeListener(OnStateChangeListener listener) {
        if (listener != null && !listeners.contains(listener)) {
            listeners.add(listener);
        }
    }

    public void removeOnStateChangeListener(OnStateChangeListener listener) {
        listeners.remove(listener);
    }

    private void notifyChange(String key, Object value) {
        for (OnStateChangeListener l : listeners) {
            l.onStateChanged(key, value);
        }
    }

    public boolean isConnected() {
        return connected;
    }

    public void setConnected(boolean connected) {
        this.connected = connected;
        notifyChange("connected", connected);
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public double getServoTilt() {
        return servoTilt;
    }

    public void setServoTilt(double servoTilt) {
        this.servoTilt = servoTilt;
        notifyChange("servoTilt", servoTilt);
    }

    public boolean isTinymlEnabled() {
        return tinymlEnabled;
    }

    public void setTinymlEnabled(boolean tinymlEnabled) {
        this.tinymlEnabled = tinymlEnabled;
        notifyChange("tinymlEnabled", tinymlEnabled);
    }

    public boolean isAutoAlignEnabled() {
        return autoAlignEnabled;
    }

    public void setAutoAlignEnabled(boolean autoAlignEnabled) {
        this.autoAlignEnabled = autoAlignEnabled;
        notifyChange("autoAlignEnabled", autoAlignEnabled);
    }

    public double getLastThroughput() {
        return lastThroughput;
    }

    public void setLastThroughput(double lastThroughput) {
        this.lastThroughput = lastThroughput;
        notifyChange("throughput", lastThroughput);
    }

    public double getLastBer() {
        return lastBer;
    }

    public void setLastBer(double lastBer) {
        this.lastBer = lastBer;
        notifyChange("ber", lastBer);
    }

    public double getLastRssi() {
        return lastRssi;
    }

    public void setLastRssi(double lastRssi) {
        this.lastRssi = lastRssi;
        notifyChange("rssi", lastRssi);
    }

    public double getLastAlignmentPrecision() {
        return lastAlignmentPrecision;
    }

    public void setLastAlignmentPrecision(double lastAlignmentPrecision) {
        this.lastAlignmentPrecision = lastAlignmentPrecision;
        notifyChange("alignmentPrecision", lastAlignmentPrecision);
    }

    public double getLastVisibility() {
        return lastVisibility;
    }

    public void setLastVisibility(double lastVisibility) {
        this.lastVisibility = lastVisibility;
        notifyChange("visibility", lastVisibility);
    }

    public double getLastAttenuation() {
        return lastAttenuation;
    }

    public void setLastAttenuation(double lastAttenuation) {
        this.lastAttenuation = lastAttenuation;
        notifyChange("attenuation", lastAttenuation);
    }

    public double getLastHumidity() {
        return lastHumidity;
    }

    public void setLastHumidity(double lastHumidity) {
        this.lastHumidity = lastHumidity;
        notifyChange("humidity", lastHumidity);
    }

    public double getEspTemp() {
        return espTemp;
    }

    public void setEspTemp(double espTemp) {
        this.espTemp = espTemp;
        notifyChange("espTemp", espTemp);
    }

    public double getEspEtat() {
        return espEtat;
    }

    public void setEspEtat(double espEtat) {
        this.espEtat = espEtat;
        notifyChange("espEtat", espEtat);
    }

    public String getEspUptime() {
        return espUptime;
    }

    public void setEspUptime(String espUptime) {
        this.espUptime = espUptime;
        notifyChange("espUptime", espUptime);
    }

    public double getLightIntensity() {
        return lightIntensity;
    }

    public void setLightIntensity(double lightIntensity) {
        this.lightIntensity = lightIntensity;
        notifyChange("lightIntensity", lightIntensity);
    }

    public String getCh1Status() {
        return ch1Status;
    }

    public void setCh1Status(String ch1Status) {
        this.ch1Status = ch1Status;
    }

    public String getCh2Status() {
        return ch2Status;
    }

    public void setCh2Status(String ch2Status) {
        this.ch2Status = ch2Status;
    }

    public String getCh3Status() {
        return ch3Status;
    }

    public void setCh3Status(String ch3Status) {
        this.ch3Status = ch3Status;
    }

    public int[] getBarValues() {
        return barValues;
    }

    public void pushBarValue(int newValue) {
        // Shift all values left
        System.arraycopy(barValues, 1, barValues, 0, barValues.length - 1);
        barValues[barValues.length - 1] = newValue;
        notifyChange("barValues", barValues);
    }
}
