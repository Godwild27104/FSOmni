package com.fso.fsoomni.view;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;

import com.fso.fsoomni.R;

public class BarChartView extends View {

    private static final int BAR_COUNT = 12;
    private int[] values = {65, 72, 58, 80, 92, 85, 70, 95, 88, 78, 90, 98};
    private int[] animatedValues = new int[BAR_COUNT];
    private float[] barHeights = new float[BAR_COUNT];
    private float barWidth = 0;
    private float barGap = 6f;
    private float chartHeight = 0;

    private Paint barPaint;
    private Paint barDimPaint;
    private LinearGradient barGradient;
    private LinearGradient barDimGradient;

    public BarChartView(Context context) {
        super(context);
        init();
    }

    public BarChartView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public BarChartView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        init();
    }

    private void init() {
        System.arraycopy(values, 0, animatedValues, 0, BAR_COUNT);

        barPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        barPaint.setColor(Color.parseColor("#00488D"));

        barDimPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        barDimPaint.setColor(Color.parseColor("#A8C8FF"));
        barDimPaint.setAlpha(102); // 0.4 opacity

        for (int i = 0; i < BAR_COUNT; i++) {
            barHeights[i] = values[i] / 100f;
        }
    }

    public void setValues(int[] newValues) {
        if (newValues == null || newValues.length != BAR_COUNT) return;

        int[] oldValues = animatedValues.clone();
        for (int i = 0; i < BAR_COUNT; i++) {
            values[i] = newValues[i];
            final int idx = i;
            final float oldH = oldValues[i] / 100f;
            final float newH = newValues[i] / 100f;

            ValueAnimator anim = ValueAnimator.ofFloat(oldH, newH);
            anim.setDuration(500);
            anim.setInterpolator(new AccelerateDecelerateInterpolator());
            anim.addUpdateListener(animation -> {
                barHeights[idx] = (float) animation.getAnimatedValue();
                animatedValues[idx] = (int) (barHeights[idx] * 100);
                invalidate();
            });
            anim.start();
        }
    }

    public void pushValue(int newValue) {
        // Shift left and add new value
        System.arraycopy(values, 1, values, 0, BAR_COUNT - 1);
        values[BAR_COUNT - 1] = newValue;

        // Animate shift
        for (int i = 0; i < BAR_COUNT; i++) {
            final int idx = i;
            final float oldH = barHeights[Math.max(0, idx - 1)];
            final float newH = values[i] / 100f;

            ValueAnimator anim = ValueAnimator.ofFloat(barHeights[idx], newH);
            anim.setDuration(500);
            anim.setInterpolator(new AccelerateDecelerateInterpolator());
            anim.addUpdateListener(animation -> {
                barHeights[idx] = (float) animation.getAnimatedValue();
                invalidate();
            });
            anim.start();
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        chartHeight = h;
        float totalGap = barGap * (BAR_COUNT - 1);
        barWidth = (w - totalGap) / BAR_COUNT;

        // Create gradient for latest bar
        barGradient = new LinearGradient(0, chartHeight, 0, 0,
                Color.parseColor("#005FB8"), Color.parseColor("#00488D"),
                Shader.TileMode.CLAMP);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        if (barWidth <= 0 || chartHeight <= 0) return;

        float x = 0;
        float paddingTop = 8f * getResources().getDisplayMetrics().density;
        float availableHeight = chartHeight - paddingTop;

        for (int i = 0; i < BAR_COUNT; i++) {
            float height = barHeights[i] * availableHeight;
            float y = chartHeight - height;

            Paint paint;
            if (i == BAR_COUNT - 1) {
                // Latest bar - gradient, full opacity
                barPaint.setShader(barGradient);
                paint = barPaint;
            } else {
                // Dim bars
                paint = barDimPaint;
            }

            float cornerRadius = 4f * getResources().getDisplayMetrics().density;
            canvas.drawRoundRect(x, y, x + barWidth, chartHeight, cornerRadius, cornerRadius, paint);

            x += barWidth + barGap;
        }
    }
}
