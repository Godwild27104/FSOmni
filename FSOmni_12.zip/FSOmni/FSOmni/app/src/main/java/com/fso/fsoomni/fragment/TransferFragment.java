package com.fso.fsoomni.fragment;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fso.fsoomni.R;
import com.fso.fsoomni.adapter.ChatMessageAdapter;
import com.fso.fsoomni.model.AppState;
import com.fso.fsoomni.model.ChatMessage;
import com.fso.fsoomni.view.WaveformView;
import com.fso.fsoomni.websocket.FSOWebSocketClient;

import java.util.Arrays;
import java.util.List;

public class TransferFragment extends Fragment {

    private AppState appState;
    private FSOWebSocketClient wsClient;
    private Handler handler = new Handler(Looper.getMainLooper());

    private RecyclerView chatMessages;
    private ChatMessageAdapter chatAdapter;
    private EditText chatInput;
    private ImageButton btnMic;
    private ImageButton btnSend;
    private LinearLayout voiceBar;
    private WaveformView waveform;
    private TextView voiceTimer;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getActivity() != null) {
            appState = ((com.fso.fsoomni.activity.MainActivity) getActivity()).getAppState();
            wsClient = ((com.fso.fsoomni.activity.MainActivity) getActivity()).getWsClient();
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_transfer, container, false);

        chatMessages = view.findViewById(R.id.chat_messages);
        chatInput = view.findViewById(R.id.chat_input);
        btnMic = view.findViewById(R.id.btn_mic);
        btnSend = view.findViewById(R.id.btn_send);
        voiceBar = view.findViewById(R.id.voice_bar);
        waveform = view.findViewById(R.id.waveform);
        voiceTimer = view.findViewById(R.id.voice_timer);

        // Setup RecyclerView
        chatMessages.setLayoutManager(new LinearLayoutManager(requireContext()));
        chatAdapter = new ChatMessageAdapter(requireContext());
        chatMessages.setAdapter(chatAdapter);

        // Add initial messages
        List<ChatMessage> initialMessages = Arrays.asList(
                new ChatMessage(ChatMessage.MessageType.INCOMING, "Spéro", "Système prêt pour la transmission. Liaison stable à 1 Gbps.", "10:42"),
                new ChatMessage(ChatMessage.MessageType.OUTGOING, "Initialisation de la séquence de test alpha-1.", "10:45"),
                new ChatMessage(ChatMessage.MessageType.INCOMING, "Spéro", "Test alpha-1 reçu sans perte de paquets. Signal : 98%.", "10:46")
        );
        chatAdapter.setMessages(initialMessages);
        chatMessages.scrollToPosition(initialMessages.size() - 1);

        // Text input listener
        chatInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 0) {
                    btnMic.setVisibility(View.GONE);
                    btnSend.setVisibility(View.VISIBLE);
                } else {
                    btnMic.setVisibility(View.VISIBLE);
                    btnSend.setVisibility(View.GONE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Send button
        btnSend.setOnClickListener(v -> sendMessage());

        // Mic button - show voice bar
        btnMic.setOnClickListener(v -> {
            voiceBar.setVisibility(View.VISIBLE);
            waveform.startAnimation();
            voiceTimer.setText("0:00");
        });

        // Mic recording button - stop recording
        view.findViewById(R.id.btn_mic_recording).setOnClickListener(v -> {
            voiceBar.setVisibility(View.GONE);
            waveform.stopAnimation();
        });

        // Upload zone
        view.findViewById(R.id.upload_zone).setOnClickListener(v -> {
            // In a real app, this would open a file picker
            // For now, we just show a visual feedback
        });

        // Transmit button
        view.findViewById(R.id.btn_transmit).setOnClickListener(v -> {
            // Send file transmission command
            if (wsClient != null) {
                com.google.gson.JsonObject payload = new com.google.gson.JsonObject();
                payload.addProperty("name", "test.bin");
                payload.addProperty("size", 1024);
                payload.addProperty("chunks", 1);
                wsClient.sendMessage("file_tx_start", payload);
            }
        });

        return view;
    }

    private void sendMessage() {
        String text = chatInput.getText().toString().trim();
        if (text.isEmpty()) return;

        // Get current time
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("HH:mm");
        String time = sdf.format(new java.util.Date());

        // Add outgoing message
        ChatMessage msg = new ChatMessage(ChatMessage.MessageType.OUTGOING, text, time);
        chatAdapter.addMessage(msg);
        chatMessages.scrollToPosition(chatAdapter.getItemCount() - 1);

        // Send via WebSocket
        if (wsClient != null) {
            wsClient.sendChatMessage(text);
        }

        // Clear input
        chatInput.setText("");
    }

    @Override
    public void onPause() {
        super.onPause();
        if (waveform != null) {
            waveform.stopAnimation();
        }
    }
}
