package com.fso.fsoomni.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import android.graphics.LinearGradient;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;

public class CameraCrosshairView extends View {

    private Paint bgPaint;
    private Paint crosshairOuterPaint;
    private Paint crosshairInnerPaint;
    private Paint crosshairLinePaint;
    private Paint crosshairDotPaint;
    private Paint hudBgPaint;
    private Paint hudTextPaint;
    private Paint radarPaint;

    private LinearGradient bgGradient;
    private float density;

    public CameraCrosshairView(Context context) {
        super(context);
        init();
    }

    public CameraCrosshairView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public CameraCrosshairView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs);
        init();
    }

    private void init() {
        density = getResources().getDisplayMetrics().density;

        bgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        bgPaint.setColor(Color.parseColor("#0A0A0A"));

        crosshairOuterPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        crosshairOuterPaint.setStyle(Paint.Style.STROKE);
        crosshairOuterPaint.setColor(Color.parseColor("#60005FB8"));
        crosshairOuterPaint.setStrokeWidth(2f * density);

        crosshairInnerPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        crosshairInnerPaint.setStyle(Paint.Style.STROKE);
        crosshairInnerPaint.setColor(Color.parseColor("#30005FB8"));
        crosshairInnerPaint.setStrokeWidth(1f * density);

        crosshairLinePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        crosshairLinePaint.setColor(Color.parseColor("#30005FB8"));
        crosshairLinePaint.setStrokeWidth(1f * density);

        crosshairDotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        crosshairDotPaint.setColor(Color.parseColor("#BA1A1A"));
        crosshairDotPaint.setShadowLayer(8f * density, 0, 0, Color.parseColor("#80BA1A1A"));

        hudBgPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        hudBgPaint.setColor(Color.parseColor("#99000000"));

        hudTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        hudTextPaint.setColor(Color.WHITE);
        hudTextPaint.setTextSize(11f * density);
        hudTextPaint.setFakeBoldText(true);

        radarPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        radarPaint.setColor(Color.parseColor("#30005FB8"));
        radarPaint.setTextSize(48f * density);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        bgGradient = new LinearGradient(0, 0, w, h,
                Color.parseColor("#0A0F1A"), Color.parseColor("#1A1A2E"),
                Shader.TileMode.CLAMP);
        bgPaint.setShader(bgGradient);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float w = getWidth();
        float h = getHeight();
        float cx = w / 2f;
        float cy = h / 2f;

        // Background
        canvas.drawRect(0, 0, w, h, bgPaint);

        // Radar icon placeholder (center)
        hudTextPaint.setTextSize(40f * density);
        hudTextPaint.setAlpha(77);
        canvas.drawText("◉", cx - hudTextPaint.measureText("◉") / 2f, cy + 14f * density, hudTextPaint);

        // Crosshair - Horizontal line
        canvas.drawLine(0, cy, w, cy, crosshairLinePaint);

        // Crosshair - Vertical line
        canvas.drawLine(cx, 0, cx, h, crosshairLinePaint);

        // Outer circle
        float outerRadius = 60f * density;
        canvas.drawCircle(cx, cy, outerRadius, crosshairOuterPaint);

        // Inner circle
        float innerRadius = 40f * density;
        canvas.drawCircle(cx, cy, innerRadius, crosshairInnerPaint);

        // Center dot
        float dotRadius = 4f * density;
        canvas.drawCircle(cx, cy, dotRadius, crosshairDotPaint);

        // HUD Panel - Top Left
        hudTextPaint.setTextSize(11f * density);
        hudTextPaint.setAlpha(255);
        float hudPadding = 8f * density;
        float hudMarginTop = 12f * density;
        float hudMarginLeft = 12f * density;
        float hudLineSpacing = 16f * density;

        float hudTextX = hudMarginLeft + hudPadding;
        float hudTextY = hudMarginTop + hudPadding + 11f * density;

        // HUD background
        float hudBgWidth = 80f * density;
        float hudBgHeight = hudLineSpacing * 4 + hudPadding * 2;
        RectF hudRect = new RectF(hudMarginLeft, hudMarginTop, hudMarginLeft + hudBgWidth, hudMarginTop + hudBgHeight);
        canvas.drawRoundRect(hudRect, 8f * density, 8f * density, hudBgPaint);

        // HUD text lines
        canvas.drawText("FPS  60.2", hudTextX, hudTextY, hudTextPaint);
        canvas.drawText("LAT  14ms", hudTextX, hudTextY + hudLineSpacing, hudTextPaint);
        hudTextPaint.setColor(Color.parseColor("#005FB8"));
        canvas.drawText("MODE AUTO", hudTextX, hudTextY + hudLineSpacing * 2, hudTextPaint);
        hudTextPaint.setColor(Color.parseColor("#BA1A1A"));
        canvas.drawText("SIG  84%", hudTextX, hudTextY + hudLineSpacing * 3, hudTextPaint);

        // Reset color
        hudTextPaint.setColor(Color.WHITE);

        // Gain Slider Label - Bottom Left
        float gainY = h - 40f * density;
        float gainMarginLeft = 12f * density;
        float gainLabelY = gainY - 10f * density;

        RectF gainRect = new RectF(gainMarginLeft, gainY - 4f * density, w - 12f * density, h - 8f * density);
        canvas.drawRoundRect(gainRect, 8f * density, 8f * density, hudBgPaint);

        hudTextPaint.setTextSize(10f * density);
        hudTextPaint.setAlpha(179); // 0.7 opacity
        canvas.drawText("GAIN DE STABILISATION", gainMarginLeft + hudPadding, gainLabelY, hudTextPaint);

        hudTextPaint.setAlpha(255);
        hudTextPaint.setTextSize(11f * density);
        canvas.drawText("42 dB", gainMarginLeft + hudPadding, gainLabelY + 18f * density, hudTextPaint);
    }
}
