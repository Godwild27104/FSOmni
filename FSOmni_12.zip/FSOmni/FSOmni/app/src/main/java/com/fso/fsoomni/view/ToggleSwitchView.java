package com.fso.fsoomni.view;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

public class ToggleSwitchView extends View {

    private boolean isChecked = true;
    private float thumbPosition = 1f; // 0 = OFF, 1 = ON

    private Paint trackOffPaint;
    private Paint trackOnPaint;
    private Paint thumbPaint;

    private float thumbRadius;
    private float trackHeight;
    private float padding;

    private OnCheckedChangeListener listener;

    public interface OnCheckedChangeListener {
        void onCheckedChanged(boolean isChecked);
    }

    public ToggleSwitchView(Context context) {
        super(context);
        init();
    }

    public ToggleSwitchView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init();
    }

    public ToggleSwitchView(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs);
        init();
    }

    private void init() {
        float density = getResources().getDisplayMetrics().density;

        trackHeight = 28f * density;
        thumbRadius = 11f * density;
        padding = 3f * density;

        trackOffPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        trackOffPaint.setColor(Color.parseColor("#E3E2E6"));

        trackOnPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        trackOnPaint.setColor(Color.parseColor("#005FB8"));

        thumbPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        thumbPaint.setColor(Color.WHITE);
        thumbPaint.setShadowLayer(3f * density, 0, 1f * density, Color.parseColor("#33000000"));
    }

    public void setChecked(boolean checked) {
        this.isChecked = checked;
        animateToggle(checked ? 1f : 0f);
    }

    public boolean isChecked() {
        return isChecked;
    }

    public void setOnCheckedChangeListener(OnCheckedChangeListener listener) {
        this.listener = listener;
    }

    private void animateToggle(float target) {
        ValueAnimator anim = ValueAnimator.ofFloat(thumbPosition, target);
        anim.setDuration(300);
        anim.addUpdateListener(animation -> {
            thumbPosition = (float) animation.getAnimatedValue();
            invalidate();
        });
        anim.start();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_UP) {
            isChecked = !isChecked;
            animateToggle(isChecked ? 1f : 0f);
            if (listener != null) {
                listener.onCheckedChanged(isChecked);
            }
            return true;
        }
        return super.onTouchEvent(event);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        setMeasuredDimension(
                (int) (48f * getResources().getDisplayMetrics().density),
                (int) (28f * getResources().getDisplayMetrics().density)
        );
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        float w = getWidth();
        float h = getHeight();
        float radius = trackHeight / 2f;

        // Draw track
        RectF trackRect = new RectF(0, (h - trackHeight) / 2f, w, (h + trackHeight) / 2f);
        canvas.drawRoundRect(trackRect, radius, radius, isChecked ? trackOnPaint : trackOffPaint);

        // Draw thumb
        float thumbCenterX = padding + thumbRadius + thumbPosition * (w - 2 * padding - 2 * thumbRadius);
        float thumbCenterY = h / 2f;
        canvas.drawCircle(thumbCenterX, thumbCenterY, thumbRadius, thumbPaint);
    }
}
