// ================================================================
// wifi_ws.h — Gestion WiFi et WebSocket pour l'ÉTAPE 1 & 2
// ================================================================

#ifndef WIFI_WS_H
#define WIFI_WS_H

#include <WiFi.h>
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include <ArduinoJson.h>
#include "config.h"
#include "protocol.h"
#include "laser_comm.h"

// Objets serveur et WebSocket
AsyncWebServer server(WS_PORT);
AsyncWebSocket ws("/");  // ✅ CORRECTION : Chemin racine "/" au lieu de "/ws"

// ================================================================
// Gestionnaire d'événements WebSocket
// ================================================================
void onWsEvent(AsyncWebSocket *server, AsyncWebSocketClient *client, 
               AwsEventType type, void *arg, uint8_t *data, size_t len) {
  
  switch(type) {
    case WS_EVT_CONNECT:
      // Client connecté
      Serial.printf("✅ Client WebSocket connecté [ID: %u] depuis %s\n", 
                    client->id(), client->remoteIP().toString().c_str());
      
      // Envoyer un message de bienvenue
      {
        StaticJsonDocument<256> doc;
        doc["type"] = "connected";  // ✅ CORRECTION : type en chaîne
        doc["message"] = "Bienvenue sur ESP32 FSOmni";
        doc["device"] = "ESP32-S3";
        doc["firmware_version"] = "1.0.0";
        
        String jsonString;
        serializeJson(doc, jsonString);
        client->text(jsonString);
        
        Serial.printf("📤 Message de bienvenue envoyé : %s\n", jsonString.c_str());
      }
      
      // Envoyer des données de télémétrie initiales
      {
        StaticJsonDocument<512> telemetry;
        telemetry["type"] = "telemetry";
        telemetry["throughput"] = 9.8;
        telemetry["ber"] = 1.2e-9;
        telemetry["rssi"] = -42.0;
        telemetry["alignment_precision"] = 90.0;
        
        String telemetryStr;
        serializeJson(telemetry, telemetryStr);
        client->text(telemetryStr);
        
        Serial.printf("📤 Télémétrie initiale envoyée : %s\n", telemetryStr.c_str());
      }
      break;
      
    case WS_EVT_DISCONNECT:
      // Client déconnecté
      Serial.printf("🔌 Client WebSocket déconnecté [ID: %u]\n", client->id());
      break;
      
    case WS_EVT_DATA:
      // Données reçues du client
      {
        AwsFrameInfo *info = (AwsFrameInfo*)arg;
        if (info->final && info->index == 0 && info->len == len) {
          // Message complet reçu
          if (info->opcode == WS_TEXT) {
            // Message texte JSON
            data[len] = 0;  // Null-terminate
            String message = String((char*)data);
            Serial.printf("📩 Message reçu du client [ID: %u] : %s\n", client->id(), message.c_str());
            
            // Parser le JSON
            StaticJsonDocument<512> doc;
            DeserializationError error = deserializeJson(doc, message);
            
            if (!error) {
              const char* msgType = doc["type"];
              Serial.printf("   Type de message : %s\n", msgType);
              
              // ================================================================
              // ÉTAPE 2 : Gestion des messages laser
              // ================================================================
              
              // Vérifier si c'est un type numérique (nouveau protocole)
              if (doc["type"].is<int>()) {
                int typeNum = doc["type"];
                
                if (typeNum == MSG_TEXT_MESSAGE) {
                  // Message texte à transmettre par laser
                  const char* text = doc["text"];
                  int unitId = doc.containsKey("unit_id") ? doc["unit_id"].as<int>() : 0;
                  
                  Serial.printf("   → Message texte à transmettre : unit_id=%d, text=\"%s\"\n", unitId, text);
                  
                  if (transmitText(String(text), unitId)) {
                    // Transmission démarrée avec succès
                    client->text("{\"type\":10,\"status\":\"tx_started\"}");
                  } else {
                    // Erreur de transmission
                    client->text(createErrorJson("Transmission déjà en cours"));
                  }
                }
                else if (typeNum == MSG_PING) {
                  // Répondre au ping avec uptime
                  String pong = createPongJson();
                  client->text(pong);
                  Serial.printf("   → PONG envoyé : %s\n", pong.c_str());
                }
              }
              
              // ================================================================
              // Ancien protocole (compatibilité ÉTAPE 1)
              // ================================================================
              
              // Répondre selon le type de message
              if (strcmp(msgType, "ping") == 0) {
                // Répondre au ping
                client->text("{\"type\":\"pong\",\"timestamp\":" + String(millis()) + "}");
              }
              else if (strcmp(msgType, "servo") == 0) {
                // Commande servo (à implémenter plus tard)
                Serial.println("   → Commande servo reçue");
              }
              else if (strcmp(msgType, "auto_align") == 0) {
                // Commande auto-alignement (à implémenter plus tard)
                Serial.println("   → Commande auto-align reçue");
              }
            } else {
              Serial.printf("   ❌ Erreur parsing JSON : %s\n", error.c_str());
            }
          }
        }
      }
      break;
      
    case WS_EVT_PONG:
      Serial.printf("🏓 Pong reçu du client [ID: %u]\n", client->id());
      break;
      
    case WS_EVT_ERROR:
      Serial.printf("❌ Erreur WebSocket client [ID: %u]\n", client->id());
      break;
  }
}

// ================================================================
// Initialisation WiFi et WebSocket
// ================================================================
void initWifiWs() {
  // Configuration du point d'accès WiFi
  Serial.println("Configuration du point d'accès WiFi...");
  
  WiFi.mode(WIFI_AP);
  WiFi.softAP(WIFI_SSID, WIFI_PASSWORD, WIFI_CHANNEL, 0, MAX_CLIENTS);
  
  IPAddress IP = WiFi.softAPIP();
  Serial.print("Point d'accès WiFi démarré : ");
  Serial.println(WIFI_SSID);
  Serial.print("Mot de passe : ");
  Serial.println(WIFI_PASSWORD);
  Serial.print("Adresse IP : ");
  Serial.println(IP);
  
  // Configuration du WebSocket
  ws.onEvent(onWsEvent);
  server.addHandler(&ws);
  
  // Route par défaut pour le serveur HTTP
  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request){
    request->send(200, "text/html", 
      "<html><body>"
      "<h1>ESP32 FSOmni</h1>"
      "<p>Serveur WebSocket actif sur ws://" + WiFi.softAPIP().toString() + ":8080/</p>"
      "<p>Connectez-vous avec l'application Android FSOmni</p>"
      "</body></html>");
  });
  
  // Démarrage du serveur
  server.begin();
  Serial.println("Serveur WebSocket démarré sur le port 8080");
  Serial.println("Chemin WebSocket : ws://192.168.4.1:8080/");
  Serial.println("En attente de connexions...");
}

// ================================================================
// Boucle de maintenance WiFi/WebSocket
// ================================================================
void wifiWsLoop() {
  ws.cleanupClients();
  
  // ================================================================
  // ÉTAPE 2 : Broadcaster les messages reçus par laser avec unit_id
  // ================================================================
  if (!receivedText.isEmpty()) {
    // Créer le message JSON avec le texte reçu ET le unit_id
    StaticJsonDocument<512> doc;
    doc["type"] = MSG_TEXT_MESSAGE;
    doc["text"] = receivedText;
    doc["length"] = receivedText.length();
    
    // Ajouter le unit_id si présent
    if (receivedUnitId > 0) {
      doc["unit_id"] = receivedUnitId;
    }
    
    String jsonMsg;
    serializeJson(doc, jsonMsg);
    
    // Envoyer à tous les clients WebSocket connectés
    ws.textAll(jsonMsg);
    
    Serial.printf("📤 Message laser diffusé aux clients : %s\n", jsonMsg.c_str());
    
    // Vider les buffers
    receivedText = "";
    receivedUnitId = 0;
  }
}

#endif
