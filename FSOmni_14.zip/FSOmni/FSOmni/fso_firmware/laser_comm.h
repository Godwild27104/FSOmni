// ================================================================
// laser_comm.h — Communication Laser OOK (On-Off Keying)
// ================================================================
// Gère la transmission et réception de données par laser sur 3 canaux
// en parallèle avec modulation OOK et timers hardware ESP32.
// ================================================================

#ifndef LASER_COMM_H
#define LASER_COMM_H

#include <Arduino.h>
#include "protocol.h"

// ================================================================
// CONFIGURATION GPIO — ESP32-S3 SAFE PINS
// ================================================================
// Ces GPIO sont SÛRS sur ESP32-S3 (pas de conflit flash/PSRAM)
#define TX1_PIN 10   // Laser TX canal 1
#define TX2_PIN 11   // Laser TX canal 2
#define TX3_PIN 12   // Laser TX canal 3

#define RX1_PIN 13   // Photodiode RX canal 1
#define RX2_PIN 14   // Photodiode RX canal 2
#define RX3_PIN 15   // Photodiode RX canal 3

// ================================================================
// PARAMÈTRES DE COMMUNICATION
// ================================================================
#define BIT_DURATION_US     5000    // 5ms par bit = 200 bits/s par canal
#define NUM_CHANNELS        3       // 3 canaux en parallèle = 600 bits/s total
#define MAX_FRAME_SIZE      512     // Taille max d'une trame (octets)

// Protocole OOK
#define PREAMBLE_PATTERN    0xAA    // Préambule pour synchronisation
#define PREAMBLE_LENGTH     8       // 8 octets de préambule
#define SYNC_WORD           0x7E    // Mot de synchronisation
#define FRAME_HEADER        0x02    // Début de trame (STX)
#define FRAME_FOOTER        0x03    // Fin de trame (ETX)
#define ESCAPE_BYTE         0x1B    // Byte d'échappement

// PWM pour les lasers
#define TX_PWM_FREQ         1000    // 1 kHz
#define TX_PWM_RESOLUTION   8       // 8 bits (0-255)
#define DEFAULT_PWM_POWER   180     // Puissance par défaut (70%)

// ================================================================
// VARIABLES GLOBALES
// ================================================================

// Configuration des canaux
const uint8_t txPins[NUM_CHANNELS] = {TX1_PIN, TX2_PIN, TX3_PIN};
const uint8_t rxPins[NUM_CHANNELS] = {RX1_PIN, RX2_PIN, RX3_PIN};

// États de transmission et réception
TxState txState;
RxState rxState;

// Buffers de transmission et réception (volatiles pour ISR)
volatile uint8_t txBuffer[MAX_FRAME_SIZE];
volatile uint16_t txBufferLen = 0;
volatile uint16_t txBitGroupIndex = 0;  // Index du groupe de 3 bits (un par canal)
volatile bool txBusy = false;

volatile uint8_t rxBuffer[MAX_FRAME_SIZE];
volatile uint16_t rxBufferLen = 0;
volatile uint16_t rxBitGroupIndex = 0;
volatile bool rxFrameComplete = false;

// Timers hardware
hw_timer_t *txTimer = NULL;
hw_timer_t *rxTimer = NULL;

// Message reçu (à broadcaster via WebSocket)
String receivedText = "";
int receivedUnitId = 0;  // ÉTAPE 2 : Stocker le unit_id reçu

// ================================================================
// ISR — TRANSMISSION (Timer 0)
// ================================================================
void IRAM_ATTR onTxTimer() {
  if (!txBusy) return;
  
  // Pour chaque canal, envoyer le bit correspondant
  bool allChannelsDone = true;
  
  for (int ch = 0; ch < NUM_CHANNELS; ch++) {
    // Calculer l'index du bit pour ce canal
    // Les bits sont entrelacés : ch0_bit0, ch1_bit0, ch2_bit0, ch0_bit1, ch1_bit1, ...
    uint32_t bitIdx = txBitGroupIndex * NUM_CHANNELS + ch;
    uint32_t byteIndex = bitIdx / 8;
    uint8_t bitPos = bitIdx % 8;
    
    // Si on a dépassé la fin du buffer, éteindre ce laser
    if (byteIndex >= txBufferLen) {
      ledcWrite(txPins[ch], 0);  // Nouvelle API : ledcWrite(pin, duty)
      continue;
    }
    
    allChannelsDone = false;
    
    // Lire le bit à transmettre
    uint8_t bit = (txBuffer[byteIndex] >> bitPos) & 0x01;
    
    // Transmettre : bit 1 = laser ON, bit 0 = laser OFF
    if (bit) {
      ledcWrite(txPins[ch], txState.pwmPower);
    } else {
      ledcWrite(txPins[ch], 0);
    }
  }
  
  // Si tous les canaux ont terminé, arrêter la transmission
  if (allChannelsDone) {
    // Éteindre tous les lasers
    for (int ch = 0; ch < NUM_CHANNELS; ch++) {
      ledcWrite(txPins[ch], 0);
    }
    txBusy = false;
    txState.active = false;
    return;
  }
  
  // Passer au groupe de bits suivant
  txBitGroupIndex++;
}

// ================================================================
// ISR — RÉCEPTION (Timer 1)
// ================================================================
void IRAM_ATTR onRxTimer() {
  if (rxFrameComplete) return;
  
  // Lire les 3 canaux en parallèle
  for (int ch = 0; ch < NUM_CHANNELS; ch++) {
    uint32_t bitIdx = rxBitGroupIndex * NUM_CHANNELS + ch;
    uint32_t byteIndex = bitIdx / 8;
    uint8_t bitPos = bitIdx % 8;
    
    // Protection contre débordement
    if (byteIndex >= MAX_FRAME_SIZE) {
      rxFrameComplete = true;
      rxState.errorCount++;
      return;
    }
    
    // Lire la valeur du GPIO RX
    uint8_t bit = digitalRead(rxPins[ch]) ? 1 : 0;
    
    // Écrire le bit dans le buffer
    if (bit) {
      rxBuffer[byteIndex] |= (1 << bitPos);
    } else {
      rxBuffer[byteIndex] &= ~(1 << bitPos);
    }
  }
  
  rxBitGroupIndex++;
  
  // Vérifier si on a reçu un FRAME_FOOTER
  // (Simple heuristique : chercher 0x03 dans les derniers octets)
  if (rxBitGroupIndex > 16) {  // Attendre au moins quelques octets
    uint32_t lastByteIdx = (rxBitGroupIndex * NUM_CHANNELS) / 8;
    if (lastByteIdx > 0 && lastByteIdx < MAX_FRAME_SIZE) {
      if (rxBuffer[lastByteIdx - 1] == FRAME_FOOTER) {
        rxFrameComplete = true;
        rxBufferLen = lastByteIdx;
      }
    }
  }
}

// ================================================================
// INITIALISATION
// ================================================================
void initLaserComm() {
  Serial.println("Initialisation de la communication laser OOK...");
  
  // --- Configuration des GPIO TX (PWM LEDC) ---
  // ESP32 Core 3.x utilise ledcAttach() au lieu de ledcSetup() + ledcAttachPin()
  for (int ch = 0; ch < NUM_CHANNELS; ch++) {
    // Nouvelle API : ledcAttach(pin, freq, resolution)
    ledcAttach(txPins[ch], TX_PWM_FREQ, TX_PWM_RESOLUTION);
    ledcWrite(txPins[ch], 0);  // Éteindre le laser par défaut
    Serial.printf("  TX Canal %d : GPIO %d (PWM LEDC)\n", ch + 1, txPins[ch]);
  }
  
  // --- Configuration des GPIO RX (INPUT avec PULLUP) ---
  for (int ch = 0; ch < NUM_CHANNELS; ch++) {
    pinMode(rxPins[ch], INPUT_PULLUP);
    Serial.printf("  RX Canal %d : GPIO %d (INPUT_PULLUP)\n", ch + 1, rxPins[ch]);
  }
  
  // --- Création du timer TX (Timer 0) ---
  // Nouvelle API : timerBegin(frequency) au lieu de timerBegin(id, prescaler, countUp)
  // Fréquence = 1 / BIT_DURATION_US = 1 / 0.005s = 200 Hz
  uint32_t timerFrequency = 1000000 / BIT_DURATION_US;  // 200 Hz
  txTimer = timerBegin(timerFrequency);
  timerAttachInterrupt(txTimer, &onTxTimer);
  // Pas besoin de timerAlarmWrite avec la nouvelle API
  
  // --- Création du timer RX (Timer 1) ---
  rxTimer = timerBegin(timerFrequency);
  timerAttachInterrupt(rxTimer, &onRxTimer);
  
  Serial.printf("Communication laser initialisée (3 canaux, %d bits/s total)\n", 
                (1000000 / BIT_DURATION_US) * NUM_CHANNELS);
}

// ================================================================
// TRANSMISSION DE TEXTE
// ================================================================
bool transmitText(const String& text, int unitId) {
  // Vérifier qu'une transmission n'est pas déjà en cours
  if (txBusy) {
    Serial.println("❌ Transmission déjà en cours");
    return false;
  }
  
  // Construire le payload avec unit_id:text
  String payload;
  if (unitId > 0) {
    payload = String(unitId) + ":" + text;
  } else {
    payload = "0:" + text;  // 0 = Inconnu
  }
  
  Serial.printf("📡 Préparation transmission : unit_id=%d, text=\"%s\"\n", unitId, text.c_str());
  Serial.printf("   Payload laser : \"%s\" (%d octets)\n", payload.c_str(), payload.length());
  
  // --- Construction de la trame ---
  uint16_t framePos = 0;
  
  // 1. Préambule (synchronisation)
  for (int i = 0; i < PREAMBLE_LENGTH; i++) {
    txBuffer[framePos++] = PREAMBLE_PATTERN;
  }
  
  // 2. Mot de synchronisation
  txBuffer[framePos++] = SYNC_WORD;
  
  // 3. En-tête de trame
  txBuffer[framePos++] = FRAME_HEADER;
  
  // 4. Payload (avec échappement des octets spéciaux)
  for (unsigned int i = 0; i < payload.length(); i++) {
    uint8_t byte = payload[i];
    
    // Échapper les octets spéciaux
    if (byte == FRAME_HEADER || byte == FRAME_FOOTER || byte == ESCAPE_BYTE) {
      txBuffer[framePos++] = ESCAPE_BYTE;
    }
    
    txBuffer[framePos++] = byte;
    
    // Vérifier débordement
    if (framePos >= MAX_FRAME_SIZE - 2) {
      Serial.println("❌ Message trop long");
      return false;
    }
  }
  
  // 5. Pied de trame
  txBuffer[framePos++] = FRAME_FOOTER;
  
  txBufferLen = framePos;
  
  Serial.printf("  Trame construite : %d octets (préambule + header + payload + footer)\n", txBufferLen);
  
  // --- Démarrage de la transmission ---
  txBitGroupIndex = 0;
  txBusy = true;
  txState.active = true;
  txState.totalBytes = txBufferLen;
  txState.sentBytes = 0;
  txState.startTime = millis();
  
  // Activer le timer TX (nouvelle API : timerStart)
  timerStart(txTimer);
  
  Serial.println("  ✅ Transmission démarrée");
  return true;
}

// ================================================================
// DÉMARRAGE DE LA RÉCEPTION
// ================================================================
void startReceiving() {
  Serial.println("👂 Démarrage de la réception laser...");
  
  // Réinitialiser les buffers
  memset((void*)rxBuffer, 0, MAX_FRAME_SIZE);
  rxBufferLen = 0;
  rxBitGroupIndex = 0;
  rxFrameComplete = false;
  
  rxState.active = true;
  rxState.startTime = millis();
  
  // Activer le timer RX (nouvelle API)
  timerStart(rxTimer);
  
  Serial.println("  ✅ Réception active");
}

// ================================================================
// ARRÊT DE LA RÉCEPTION
// ================================================================
void stopReceiving() {
  timerStop(rxTimer);  // Nouvelle API
  rxState.active = false;
  Serial.println("🛑 Réception laser arrêtée");
}

// ================================================================
// TRAITEMENT DE LA TRAME REÇUE
// ================================================================
void processReceivedFrame() {
  Serial.printf("📥 Traitement de la trame reçue (%d octets)\n", rxBufferLen);
  
  // Chercher le FRAME_HEADER
  int headerPos = -1;
  for (int i = 0; i < rxBufferLen; i++) {
    if (rxBuffer[i] == FRAME_HEADER) {
      headerPos = i;
      break;
    }
  }
  
  if (headerPos == -1) {
    Serial.println("❌ Pas de FRAME_HEADER trouvé");
    return;
  }
  
  // Chercher le FRAME_FOOTER
  int footerPos = -1;
  for (int i = headerPos + 1; i < rxBufferLen; i++) {
    if (rxBuffer[i] == FRAME_FOOTER) {
      footerPos = i;
      break;
    }
  }
  
  if (footerPos == -1) {
    Serial.println("❌ Pas de FRAME_FOOTER trouvé");
    return;
  }
  
  // Extraire le payload (entre header et footer)
  String decoded = "";
  bool escaped = false;
  
  for (int i = headerPos + 1; i < footerPos; i++) {
    uint8_t byte = rxBuffer[i];
    
    if (escaped) {
      decoded += (char)byte;
      escaped = false;
    } else if (byte == ESCAPE_BYTE) {
      escaped = true;
    } else {
      decoded += (char)byte;
    }
  }
  
  Serial.printf("  ✅ Payload décodé : \"%s\"\n", decoded.c_str());
  
  // Séparer unit_id et texte (format: "unit_id:text")
  int colonPos = decoded.indexOf(':');
  if (colonPos > 0) {
    String unitIdStr = decoded.substring(0, colonPos);
    String actualText = decoded.substring(colonPos + 1);
    
    receivedUnitId = unitIdStr.toInt();
    receivedText = actualText;
    
    Serial.printf("  ✅ unit_id=%d, text=\"%s\"\n", receivedUnitId, receivedText.c_str());
  } else {
    // Pas de séparateur → ancien format, pas de unit_id
    receivedUnitId = 0;
    receivedText = decoded;
    Serial.printf("  ⚠️ Format sans unit_id, text=\"%s\"\n", receivedText.c_str());
  }
  
  rxState.receivedBytes = receivedText.length();
}

// ================================================================
// ARRÊT DE TOUS LES LASERS
// ================================================================
void stopAllLasers() {
  for (int ch = 0; ch < NUM_CHANNELS; ch++) {
    ledcWrite(txPins[ch], 0);  // Nouvelle API : ledcWrite(pin, duty)
  }
}

// ================================================================
// BOUCLE DE MAINTENANCE
// ================================================================
void laserCommLoop() {
  // Vérifier si la transmission est terminée
  if (txState.active && !txBusy) {
    uint32_t duration = millis() - txState.startTime;
    txState.bitRate = (txBufferLen * 8 * 1000.0) / duration;
    
    Serial.printf("✅ Transmission terminée en %d ms (débit: %.1f bits/s)\n", 
                  duration, txState.bitRate);
    
    timerStop(txTimer);  // Nouvelle API
    txState.active = false;
  }
  
  // Vérifier si une trame complète a été reçue
  if (rxFrameComplete) {
    uint32_t duration = millis() - rxState.startTime;
    rxState.bitRate = (rxBufferLen * 8 * 1000.0) / duration;
    
    Serial.printf("✅ Réception terminée en %d ms (débit: %.1f bits/s)\n", 
                  duration, rxState.bitRate);
    
    processReceivedFrame();
    
    // Réinitialiser pour la prochaine trame
    rxFrameComplete = false;
    rxBitGroupIndex = 0;
    memset((void*)rxBuffer, 0, MAX_FRAME_SIZE);
  }
}

#endif
