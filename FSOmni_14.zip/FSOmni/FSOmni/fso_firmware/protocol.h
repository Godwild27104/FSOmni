// ================================================================
// protocol.h — Protocole de communication pour l'ÉTAPE 2
// ================================================================
// Définit les structures de données et les fonctions JSON pour
// la communication laser OOK (On-Off Keying) sur 3 canaux.
// ================================================================

#ifndef PROTOCOL_H
#define PROTOCOL_H

#include <Arduino.h>
#include <ArduinoJson.h>

// ================================================================
// TYPES DE MESSAGES
// ================================================================
enum MsgType {
  MSG_TEXT_MESSAGE = 2,   // Message texte via laser
  MSG_TX_PROGRESS  = 10,  // Progression de transmission
  MSG_PING         = 12,  // Ping pour test de connectivité
  MSG_PONG         = 13,  // Réponse au ping
  MSG_ERROR        = 99   // Message d'erreur
};

// ================================================================
// STRUCTURES D'ÉTAT
// ================================================================

// État de transmission
struct TxState {
  bool active;              // Transmission en cours
  uint32_t totalBytes;      // Nombre total d'octets à envoyer
  uint32_t sentBytes;       // Nombre d'octets envoyés
  uint32_t startTime;       // Timestamp de début (ms)
  float bitRate;            // Débit en bits/s
  int8_t pwmPower;          // Puissance PWM (0-255)
  
  TxState() : active(false), totalBytes(0), sentBytes(0), 
              startTime(0), bitRate(0.0), pwmPower(180) {}
};

// État de réception
struct RxState {
  bool active;              // Réception en cours
  uint32_t totalBytes;      // Nombre total d'octets à recevoir
  uint32_t receivedBytes;   // Nombre d'octets reçus
  uint32_t startTime;       // Timestamp de début (ms)
  float bitRate;            // Débit en bits/s
  uint16_t errorCount;      // Nombre d'erreurs détectées
  
  RxState() : active(false), totalBytes(0), receivedBytes(0), 
              startTime(0), bitRate(0.0), errorCount(0) {}
};

// ================================================================
// FONCTIONS JSON — CRÉATION DE MESSAGES
// ================================================================

/**
 * Créer un message JSON pour un texte transmis par laser
 * Format: {"type":2,"text":"...","length":N}
 */
String createTextMessageJson(const String& text) {
  StaticJsonDocument<512> doc;
  doc["type"] = MSG_TEXT_MESSAGE;
  doc["text"] = text;
  doc["length"] = text.length();
  
  String output;
  serializeJson(doc, output);
  return output;
}

/**
 * Créer un message JSON de progression de transmission
 * Format: {"type":10,"current":N,"total":N,"percent":N,"bitrate":N}
 */
String createProgressJson(bool isTx, uint32_t current, uint32_t total, float bitRate) {
  StaticJsonDocument<256> doc;
  doc["type"] = MSG_TX_PROGRESS;
  doc["direction"] = isTx ? "tx" : "rx";
  doc["current"] = current;
  doc["total"] = total;
  doc["percent"] = total > 0 ? (current * 100 / total) : 0;
  doc["bitrate"] = bitRate;
  
  String output;
  serializeJson(doc, output);
  return output;
}

/**
 * Créer un message JSON d'erreur
 * Format: {"type":99,"message":"..."}
 */
String createErrorJson(const String& message) {
  StaticJsonDocument<256> doc;
  doc["type"] = MSG_ERROR;
  doc["message"] = message;
  
  String output;
  serializeJson(doc, output);
  return output;
}

/**
 * Créer un message JSON PONG
 * Format: {"type":13,"uptime_ms":N}
 */
String createPongJson() {
  StaticJsonDocument<128> doc;
  doc["type"] = MSG_PONG;
  doc["uptime_ms"] = millis();
  
  String output;
  serializeJson(doc, output);
  return output;
}

// ================================================================
// FONCTION DE PARSING
// ================================================================

/**
 * Parser un message JSON entrant et extraire le type
 * @param json String JSON à parser
 * @param type Type de message extrait (output)
 * @param doc Document JSON parsé (output)
 * @return true si parsing réussi, false sinon
 */
bool parseIncomingMessage(const String& json, MsgType& type, JsonDocument& doc) {
  DeserializationError error = deserializeJson(doc, json);
  
  if (error) {
    Serial.printf("❌ Erreur parsing JSON : %s\n", error.c_str());
    return false;
  }
  
  // Extraire le type
  if (doc.containsKey("type")) {
    int typeValue = doc["type"];
    type = static_cast<MsgType>(typeValue);
    return true;
  }
  
  Serial.println("❌ Message JSON sans champ 'type'");
  return false;
}

#endif
