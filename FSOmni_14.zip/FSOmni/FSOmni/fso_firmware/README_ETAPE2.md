# ÉTAPE 2 — TRANSFERT DE MESSAGE TEXTE VIA LASER

## 🎯 OBJECTIF
Communication laser OOK (On-Off Keying) sur 3 canaux en parallèle pour transmettre des messages texte entre deux unités ESP32-S3.

---

## 📋 FICHIERS CRÉÉS / MODIFIÉS

### ✅ Nouveaux fichiers
1. **`protocol.h`** — Structures de données et fonctions JSON
2. **`laser_comm.h`** — Gestion complète de la communication laser OOK
3. **`README_ETAPE2.md`** — Ce fichier

### ✏️ Fichiers modifiés
1. **`config.h`** — Ajout section ÉTAPE 2
2. **`wifi_ws.h`** — Intégration du protocole laser
3. **`fso_firmware.ino`** — Appels init/loop laser
4. **Android : `FSOWebSocketClient.java`** — Support type 2
5. **Android : `TransferFragment.java`** — Utilisation protocole laser

---

## 🔌 CÂBLAGE HARDWARE

### GPIO ESP32-S3 (Safe Pins)
Ces GPIO sont **SÛRS** sur ESP32-S3 (pas de conflit avec flash/PSRAM) :

| Fonction | GPIO | Description |
|----------|------|-------------|
| **TX Laser 1** | GPIO 10 | Canal 1 - PWM LEDC |
| **TX Laser 2** | GPIO 11 | Canal 2 - PWM LEDC |
| **TX Laser 3** | GPIO 12 | Canal 3 - PWM LEDC |
| **RX Photo 1** | GPIO 13 | Canal 1 - INPUT_PULLUP |
| **RX Photo 2** | GPIO 14 | Canal 2 - INPUT_PULLUP |
| **RX Photo 3** | GPIO 15 | Canal 3 - INPUT_PULLUP |

### Schéma de connexion
```
ESP32-S3 (Unité A)              ESP32-S3 (Unité B)
━━━━━━━━━━━━━━━━━              ━━━━━━━━━━━━━━━━━
GPIO 10 ──[ Laser 1 ]────────▶ [ Photodiode 1 ]── GPIO 13
GPIO 11 ──[ Laser 2 ]────────▶ [ Photodiode 2 ]── GPIO 14
GPIO 12 ──[ Laser 3 ]────────▶ [ Photodiode 3 ]── GPIO 15
```

⚠️ **ATTENTION** : Utiliser des résistances appropriées pour les lasers et des circuits de conditionnement pour les photodiodes.

---

## ⚙️ PARAMÈTRES DE COMMUNICATION

| Paramètre | Valeur | Description |
|-----------|--------|-------------|
| **Débit par canal** | 200 bits/s | 1 bit = 5ms |
| **Débit total** | 600 bits/s | 3 canaux en parallèle |
| **Modulation** | OOK | On-Off Keying (1=ON, 0=OFF) |
| **PWM Laser** | 1 kHz, 8 bits | Puissance par défaut : 180/255 (70%) |
| **Trame max** | 512 octets | Buffer de transmission |
| **Protocole** | Préambule (8×0xAA) + Sync (0x7E) + Header (0x02) + Payload + Footer (0x03) |

---

## 🧪 TESTS À EFFECTUER

### TEST 1 : Boucle locale (1 seule unité)
**Objectif** : Vérifier le TX et RX sur la même unité

1. Câbler **1 laser TX** (GPIO 10) vers **1 photodiode RX** (GPIO 13) en boucle courte
2. Téléverser le firmware sur l'ESP32-S3
3. Ouvrir le Serial Monitor (115200 baud)
4. Connecter l'app Android au WiFi "FSOmni"
5. Dans l'app, aller sur l'écran **Transfer**
6. Taper un message (ex: "test") et envoyer
7. **Vérifier dans le Serial Monitor** :
   ```
   📡 Préparation transmission : "test" (4 octets)
     Trame construite : 14 octets
     ✅ Transmission démarrée
   ✅ Transmission terminée en XXX ms (débit: ~600 bits/s)
   📥 Traitement de la trame reçue (14 octets)
     ✅ Message décodé : "test"
   📤 Message laser diffusé aux clients
   ```
8. **Vérifier dans l'app** : Le message "test" doit apparaître dans le chat avec l'émetteur "Spéro"

✅ **Critère de succès** : Message envoyé = message reçu

---

### TEST 2 : Transmission entre deux unités
**Objectif** : Vérifier la communication bidirectionnelle

1. Préparer **2 ESP32-S3** avec le firmware
2. Câbler les 3 lasers de l'unité A vers les 3 photodiodes de l'unité B
3. Câbler les 3 lasers de l'unité B vers les 3 photodiodes de l'unité A (communication bidirectionnelle)
4. Connecter 2 appareils Android :
   - **App 1** → WiFi "FSOmni" de l'unité A
   - **App 2** → WiFi "FSOmni" de l'unité B (renommer le SSID dans config.h si nécessaire)
5. Envoyer un message depuis l'app 1
6. **Vérifier** : Le message apparaît sur l'app 2
7. Envoyer un message depuis l'app 2
8. **Vérifier** : Le message apparaît sur l'app 1

✅ **Critère de succès** : Communication bidirectionnelle fonctionnelle

---

### TEST 3 : Messages longs
**Objectif** : Vérifier la gestion de messages de plus de 100 caractères

1. Dans l'app, taper un message de 150 caractères
2. Envoyer
3. **Vérifier** : Le message complet est reçu sans troncature

✅ **Critère de succès** : Message long transmis intégralement

---

### TEST 4 : Messages successifs
**Objectif** : Vérifier qu'il n'y a pas de blocage

1. Envoyer 5 messages courts rapidement (délai < 1 seconde entre chaque)
2. **Vérifier** : Tous les messages sont reçus dans l'ordre

✅ **Critère de succès** : Pas de blocage, ordre préservé

---

## 🐛 DÉBOGAGE

### Problème : "Transmission déjà en cours"
**Cause** : Le message précédent n'a pas terminé sa transmission
**Solution** : Attendre quelques secondes entre chaque envoi

### Problème : "Pas de FRAME_HEADER trouvé"
**Cause** : Mauvais alignement laser ou bruit sur les photodiodes
**Solution** :
1. Vérifier l'alignement des lasers
2. Vérifier les résistances de pull-up sur les photodiodes
3. Réduire la lumière ambiante

### Problème : Message reçu avec des caractères manquants
**Cause** : Perte de bits pendant la transmission
**Solution** :
1. Vérifier la puissance des lasers (DEFAULT_PWM_POWER dans laser_comm.h)
2. Réduire la distance entre émetteur et récepteur
3. Vérifier la stabilité de l'alignement

### Problème : Débit anormalement bas
**Cause** : BIT_DURATION_US trop élevé
**Solution** : Réduire BIT_DURATION_US dans laser_comm.h (attention : risque d'erreurs)

---

## 📊 CRITÈRES DE VALIDATION — ÉTAPE 2

✅ **À VALIDER AVANT DE PASSER À L'ÉTAPE 3** :

- [ ] Le message part et la progression s'affiche dans le Serial Monitor
- [ ] Le débit affiché est cohérent (autour de 600 bits/s)
- [ ] Le message reçu est identique au message envoyé
- [ ] Plusieurs messages successifs fonctionnent sans blocage
- [ ] Un long message (100+ caractères) passe correctement
- [ ] L'ESP32 ne plante pas (pas de watchdog reset)
- [ ] La communication bidirectionnelle fonctionne entre 2 unités

---

## 🔧 PROCHAINES ÉTAPES

Une fois l'ÉTAPE 2 validée, on pourra passer à :
- **ÉTAPE 3** : Ajout de la correction d'erreur (FEC)
- **ÉTAPE 4** : Transmission de fichiers
- **ÉTAPE 5** : Intégration des capteurs météo
- **ÉTAPE 6** : Servo d'alignement automatique
- **ÉTAPE 7** : TinyML pour optimisation

---

## 📞 SUPPORT

Si des problèmes persistent après ces tests :
1. Vérifier le Serial Monitor pour les logs détaillés
2. Vérifier que les GPIO utilisés sont bien libres sur votre carte ESP32-S3
3. Tester d'abord en boucle locale (TEST 1) avant de passer au TEST 2

**Bon courage mon frère ! 🔥**
