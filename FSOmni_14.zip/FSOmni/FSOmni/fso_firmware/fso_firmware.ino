// ================================================================
// fso_firmware.ino — Firmware principal FSOmni - ÉTAPE 1 & 2
// ================================================================
// Ce firmware crée un point d'accès WiFi et un serveur WebSocket
// pour permettre à l'application Android de se connecter.
// 
// ÉTAPE 2 : Ajout de la communication laser OOK sur 3 canaux
// ================================================================

#include "config.h"
#include "protocol.h"
#include "laser_comm.h"
#include "wifi_ws.h"

// ================================================================
// SETUP — Initialisation du système
// ================================================================
void setup() {
  // Démarrage du Serial Monitor
  Serial.begin(SERIAL_BAUD);
  delay(1000);
  
  Serial.println("========================================");
  Serial.println("  FSOmni Firmware - ÉTAPE 2");
  Serial.println("  WiFi AP + WebSocket + Laser OOK");
  Serial.println("========================================");
  
  // Initialisation de la communication laser
  initLaserComm();
  
  // Démarrage automatique de la réception
  startReceiving();
  
  // Initialisation WiFi et WebSocket
  initWifiWs();
  
  Serial.println("Système prêt");
  Serial.println("========================================");
}

// ================================================================
// LOOP — Boucle principale
// ================================================================
void loop() {
  // Maintenance WebSocket
  wifiWsLoop();
  
  // Maintenance communication laser
  laserCommLoop();
  
  // Délai court
  delay(10);
}
