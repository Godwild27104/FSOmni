package com.fso.fsoomni.activity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import com.fso.fsoomni.FSOmniApp;
import com.fso.fsoomni.R;
import com.fso.fsoomni.fragment.AlignmentFragment;
import com.fso.fsoomni.fragment.ConfigFragment;
import com.fso.fsoomni.fragment.DashboardFragment;
import com.fso.fsoomni.fragment.SettingsFragment;
import com.fso.fsoomni.fragment.TransferFragment;
import com.fso.fsoomni.model.AppState;
import com.fso.fsoomni.websocket.FSOWebSocketClient;

public class MainActivity extends AppCompatActivity {

    // Clé pour sauvegarder la page active entre recreations
    private static final String KEY_NAV_INDEX = "nav_index";

    private AppState appState;
    private FSOWebSocketClient wsClient;
    private boolean isDarkMode = false;
    private int currentNavIndex = 0; // Config (Connexion) par défaut

    // Navigation views
    private LinearLayout navDashboard, navAlignment, navTransfer, navSettings;
    private LinearLayout bottomNav;
    private ImageView navDashboardIcon, navAlignmentIcon, navTransferIcon, navSettingsIcon;
    private TextView navDashboardLabel, navAlignmentLabel, navTransferLabel, navSettingsLabel;
    private LinearLayout topbarBadge;
    private ImageButton topbarThemeBtn;
    private FrameLayout themeLoadingOverlay;

    // Fragments
    private ConfigFragment configFragment;
    private DashboardFragment dashboardFragment;
    private AlignmentFragment alignmentFragment;
    private TransferFragment transferFragment;
    private SettingsFragment settingsFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Lire la préférence de thème
        isDarkMode = getSharedPreferences(FSOmniApp.PREFS_NAME, MODE_PRIVATE)
                .getBoolean(FSOmniApp.KEY_DARK_MODE, false);

        setContentView(R.layout.activity_main);

        // Get singleton instances from Application
        appState = FSOmniApp.getAppState();
        wsClient = FSOmniApp.getWsClient();

        initViews();
        initNavigation();
        handleThemeTransitionIfNeeded();
        applyWindowInsets();

        // Restaurer la page active après recreation (changement de thème)
        if (savedInstanceState != null) {
            currentNavIndex = savedInstanceState.getInt(KEY_NAV_INDEX, 0);
        }
        navigateTo(currentNavIndex);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        // Sauvegarder la page active pour la restaurer après recreation
        outState.putInt(KEY_NAV_INDEX, currentNavIndex);
    }

    private void initViews() {
        navDashboard      = findViewById(R.id.nav_dashboard);
        navAlignment      = findViewById(R.id.nav_alignment);
        navTransfer       = findViewById(R.id.nav_transfer);
        navSettings       = findViewById(R.id.nav_settings);
        bottomNav         = findViewById(R.id.bottom_nav);

        navDashboardIcon  = findViewById(R.id.nav_dashboard_icon);
        navAlignmentIcon  = findViewById(R.id.nav_alignment_icon);
        navTransferIcon   = findViewById(R.id.nav_transfer_icon);
        navSettingsIcon   = findViewById(R.id.nav_settings_icon);

        navDashboardLabel = findViewById(R.id.nav_dashboard_label);
        navAlignmentLabel = findViewById(R.id.nav_alignment_label);
        navTransferLabel  = findViewById(R.id.nav_transfer_label);
        navSettingsLabel  = findViewById(R.id.nav_settings_label);

        topbarBadge          = findViewById(R.id.topbar_badge);
        topbarThemeBtn       = findViewById(R.id.topbar_theme_btn);
        themeLoadingOverlay  = findViewById(R.id.theme_loading_overlay);

        updateThemeIcon();
    }

    private void initNavigation() {
        navDashboard.setOnClickListener(v -> navigateTo(1));
        navAlignment.setOnClickListener(v -> navigateTo(2));
        navTransfer.setOnClickListener(v -> navigateTo(3));
        navSettings.setOnClickListener(v -> navigateTo(4));
        topbarThemeBtn.setOnClickListener(v -> toggleThemeWithLoader());
    }

    // ─────────────────────────────────────────────────────────────
    // CHANGEMENT DE THÈME avec écran de chargement fluide
    //
    // Séquence :
    //  1. Marquer la transition dans SharedPrefs
    //  2. Fade-in de l'overlay sur l'Activity courante
    //  3. Après le fade-in, appliquer setDefaultNightMode()
    //     → Android appelle recreate() automatiquement
    //  4. La nouvelle Activity lit le flag dans onCreate() et
    //     démarre avec l'overlay déjà VISIBLE (alpha=1, pas d'animation)
    //     → aucun flash car windowBackground correspond à la surface
    //  5. Une fois le layout dessiné (ViewTreeObserver), fade-out
    //     de l'overlay puis nettoyage du flag
    // ─────────────────────────────────────────────────────────────
    private void toggleThemeWithLoader() {
        isDarkMode = !isDarkMode;

        // Sauvegarder le nouveau thème + flag de transition
        getSharedPreferences(FSOmniApp.PREFS_NAME, MODE_PRIVATE)
                .edit()
                .putBoolean(FSOmniApp.KEY_DARK_MODE, isDarkMode)
                .putBoolean(FSOmniApp.KEY_THEME_TRANSITIONING, true)
                .apply();

        // 1. Fade-in de l'overlay sur l'Activity courante (120ms)
        themeLoadingOverlay.setAlpha(0f);
        themeLoadingOverlay.setVisibility(View.VISIBLE);
        themeLoadingOverlay.animate()
                .alpha(1f)
                .setDuration(120)
                .withEndAction(() ->
                    // 2. Appliquer le thème une fois l'overlay opaque
                    //    → recreate() se fera derrière l'overlay de la nouvelle Activity
                    AppCompatDelegate.setDefaultNightMode(
                            isDarkMode
                                    ? AppCompatDelegate.MODE_NIGHT_YES
                                    : AppCompatDelegate.MODE_NIGHT_NO)
                )
                .start();
    }

    /**
     * Appelé dans onCreate() : si une transition de thème était en cours,
     * afficher l'overlay immédiatement (sans animation) puis le retirer
     * dès que le premier frame est dessiné.
     */
    private void handleThemeTransitionIfNeeded() {
        boolean transitioning = getSharedPreferences(FSOmniApp.PREFS_NAME, MODE_PRIVATE)
                .getBoolean(FSOmniApp.KEY_THEME_TRANSITIONING, false);

        if (!transitioning) return;

        // Effacer le flag immédiatement
        getSharedPreferences(FSOmniApp.PREFS_NAME, MODE_PRIVATE)
                .edit()
                .putBoolean(FSOmniApp.KEY_THEME_TRANSITIONING, false)
                .apply();

        // Overlay déjà opaque dès le départ — aucun flash possible
        themeLoadingOverlay.setAlpha(1f);
        themeLoadingOverlay.setVisibility(View.VISIBLE);

        // Retirer l'overlay après que le layout est entièrement dessiné
        themeLoadingOverlay.getViewTreeObserver().addOnGlobalLayoutListener(
                new android.view.ViewTreeObserver.OnGlobalLayoutListener() {
                    @Override
                    public void onGlobalLayout() {
                        themeLoadingOverlay.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                        // Délai pour laisser le rendu se stabiliser + 500ms extra, puis fade-out
                        new Handler(Looper.getMainLooper()).postDelayed(() ->
                                themeLoadingOverlay.animate()
                                        .alpha(0f)
                                        .setDuration(220)
                                        .withEndAction(() ->
                                                themeLoadingOverlay.setVisibility(View.GONE))
                                        .start(),
                                580
                        );
                    }
                });
    }

    /**
     * Applique les window insets de manière centralisée :
     * - La bottom nav reçoit un padding bas = hauteur de la barre de navigation système
     *   → elle remonte au-dessus de la barre système, plus rien n'est caché
     * - On ne touche PAS au fragment_container car les ScrollView gèrent leur propre padding
     */
    private void applyWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(bottomNav, (v, insets) -> {
            int navBarHeight = insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom;
            
            // Ajouter padding à la bottom nav pour qu'elle s'élève au-dessus de la barre système
            v.setPadding(
                    v.getPaddingLeft(),
                    v.getPaddingTop(),
                    v.getPaddingRight(),
                    navBarHeight
            );
            
            return insets;
        });
    }

    private void updateThemeIcon() {
        if (topbarThemeBtn == null) return;
        topbarThemeBtn.setImageResource(isDarkMode ? R.drawable.ic_sun : R.drawable.ic_moon);
    }

    public void navigateTo(int index) {
        currentNavIndex = index;
        showFragment(index);
        updateNavUI(index);
    }

    private void showFragment(int index) {
        Fragment fragment = getFragment(index);
        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction ft = fm.beginTransaction();
        ft.replace(R.id.fragment_container, fragment);
        ft.commitAllowingStateLoss();
    }

    private Fragment getFragment(int index) {
        switch (index) {
            case 0:
                if (configFragment == null) configFragment = new ConfigFragment();
                return configFragment;
            case 1:
                if (dashboardFragment == null) dashboardFragment = new DashboardFragment();
                return dashboardFragment;
            case 2:
                if (alignmentFragment == null) alignmentFragment = new AlignmentFragment();
                return alignmentFragment;
            case 3:
                if (transferFragment == null) transferFragment = new TransferFragment();
                return transferFragment;
            case 4:
                if (settingsFragment == null) settingsFragment = new SettingsFragment();
                return settingsFragment;
            default:
                if (dashboardFragment == null) dashboardFragment = new DashboardFragment();
                return dashboardFragment;
        }
    }

    private void updateNavUI(int activeIndex) {
        // Cacher la bottom nav sur la vue Config (index 0), afficher sur les autres
        bottomNav.setVisibility(activeIndex == 0 ? View.GONE : View.VISIBLE);

        // Reset tous les items
        resetNavItem(navDashboard, navDashboardIcon, navDashboardLabel);
        resetNavItem(navAlignment, navAlignmentIcon, navAlignmentLabel);
        resetNavItem(navTransfer,  navTransferIcon,  navTransferLabel);
        resetNavItem(navSettings,  navSettingsIcon,  navSettingsLabel);

        topbarBadge.removeAllViews();

        // Activer le sélectionné
        switch (activeIndex) {
            case 1: activateNavItem(navDashboard, navDashboardIcon, navDashboardLabel); break;
            case 2: activateNavItem(navAlignment, navAlignmentIcon, navAlignmentLabel); break;
            case 3:
                activateNavItem(navTransfer, navTransferIcon, navTransferLabel);
                buildTransferBadge();
                break;
            case 4: activateNavItem(navSettings, navSettingsIcon, navSettingsLabel); break;
        }
    }

    private void buildTransferBadge() {
        float dp = getResources().getDisplayMetrics().density;
        int badgeColor = getResources().getColor(R.color.tertiary, getTheme());

        LinearLayout badge = new LinearLayout(this);
        badge.setOrientation(LinearLayout.HORIZONTAL);
        badge.setGravity(Gravity.CENTER_VERTICAL);
        badge.setBackgroundResource(R.drawable.bg_security_badge);
        badge.setPadding((int)(4*dp),(int)(4*dp),(int)(12*dp),(int)(4*dp));

        ImageView lock = new ImageView(this);
        lock.setImageResource(android.R.drawable.ic_lock_lock);
        lock.setColorFilter(badgeColor);
        lock.setLayoutParams(new LinearLayout.LayoutParams((int)(14*dp),(int)(14*dp)));

        TextView label = new TextView(this);
        label.setText("AES-128 Actif");
        label.setTextSize(11);
        label.setTypeface(label.getTypeface(), android.graphics.Typeface.BOLD);
        label.setTextColor(badgeColor);
        label.setLetterSpacing(0.03f);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMarginStart((int)(4*dp));
        label.setLayoutParams(lp);

        badge.addView(lock);
        badge.addView(label);
        topbarBadge.addView(badge);
    }

    private void resetNavItem(LinearLayout item, ImageView icon, TextView label) {
        item.setAlpha(0.5f);
        int color = getResources().getColor(R.color.nav_item_inactive, getTheme());
        icon.setColorFilter(color);
        label.setTextColor(color);
        item.setBackground(null);
        icon.setImageAlpha(200);
    }

    private void activateNavItem(LinearLayout item, ImageView icon, TextView label) {
        item.setAlpha(1f);
        int color = getResources().getColor(R.color.nav_item_active, getTheme());
        icon.setColorFilter(color);
        label.setTextColor(color);
        item.setBackgroundResource(R.drawable.bg_nav_item_active);
        icon.setImageAlpha(255);
    }

    public AppState getAppState()        { return appState; }
    public FSOWebSocketClient getWsClient() { return wsClient; }
}
