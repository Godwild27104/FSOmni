package com.fso.fsoomni.fragment;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.fso.fsoomni.R;
import com.fso.fsoomni.model.AppState;
import com.fso.fsoomni.websocket.FSOWebSocketClient;
import com.google.android.material.button.MaterialButton;

public class ConfigFragment extends Fragment {

    private AppState appState;
    private FSOWebSocketClient wsClient;
    private Handler handler = new Handler(Looper.getMainLooper());

    private EditText ipInput;
    private View connectionIconContainer;
    private ImageView connectionIcon;
    private TextView connectionStatus;
    private View dotEndpoint;
    private View dotJson;
    private TextView labelEndpoint;
    private TextView labelJson;
    private MaterialButton btnTestConnection;
    private FrameLayout waveContainer;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getActivity() != null) {
            appState = ((com.fso.fsoomni.activity.MainActivity) getActivity()).getAppState();
            wsClient = ((com.fso.fsoomni.activity.MainActivity) getActivity()).getWsClient();
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_config, container, false);

        ipInput = view.findViewById(R.id.ip_input);
        connectionIconContainer = view.findViewById(R.id.connection_icon_container);
        connectionIcon = view.findViewById(R.id.connection_icon);
        connectionStatus = view.findViewById(R.id.connection_status);
        dotEndpoint = view.findViewById(R.id.dot_endpoint);
        dotJson = view.findViewById(R.id.dot_json);
        labelEndpoint = view.findViewById(R.id.label_endpoint);
        labelJson = view.findViewById(R.id.label_json);
        btnTestConnection = view.findViewById(R.id.btn_test_connection);
        waveContainer = view.findViewById(R.id.wave_container);

        // Access Dashboard button
        view.findViewById(R.id.btn_access_dashboard).setOnClickListener(v -> {
            if (getActivity() != null) {
                ((com.fso.fsoomni.activity.MainActivity) getActivity()).navigateTo(1);
            }
        });

        // Test Connection button
        btnTestConnection.setOnClickListener(v -> toggleConnection());

        // Set initial IP
        if (appState != null) {
            ipInput.setText(appState.getIp());
            updateConnectionUI(appState.isConnected());
        }

        // Listen for connection state
        if (appState != null) {
            appState.addOnStateChangeListener((key, value) -> {
                if ("connected".equals(key)) {
                    handler.post(() -> updateConnectionUI((Boolean) value));
                }
            });
        }

        return view;
    }

    private void toggleConnection() {
        if (appState != null && appState.isConnected()) {
            // Disconnect
            if (wsClient != null) {
                wsClient.disconnect();
            }
        } else {
            // Connect
            testConnection();
        }
    }

    private void testConnection() {
        String ip = ipInput.getText().toString().trim();
        if (ip.isEmpty()) {
            connectionStatus.setText("⚠️ Veuillez entrer une adresse IP");
            connectionStatus.setTextColor(getResources().getColor(R.color.error, getContext().getTheme()));
            return;
        }

        if (appState != null) {
            appState.setIp(ip);
        }

        if (wsClient != null) {
            connectionStatus.setText("🔄 Tentative de connexion à " + ip + ":8080...");
            connectionStatus.setTextColor(getResources().getColor(R.color.on_surface_variant, getContext().getTheme()));
            
            // Add a listener for connection feedback
            FSOWebSocketClient.WebSocketListener connectionListener = new FSOWebSocketClient.WebSocketListener() {
                @Override
                public void onMessage(String type, com.google.gson.JsonObject data) {
                    // Not needed for connection test
                }

                @Override
                public void onConnected() {
                    handler.post(() -> {
                        if (connectionStatus != null) {
                            connectionStatus.setText("✅ Connexion réussie !");
                            connectionStatus.setTextColor(getResources().getColor(R.color.tertiary, getContext().getTheme()));
                        }
                    });
                    // Remove listener after success
                    wsClient.removeListener(this);
                }

                @Override
                public void onDisconnected() {
                    // Handled by AppState
                }

                @Override
                public void onError(String error) {
                    handler.post(() -> {
                        if (connectionStatus != null) {
                            connectionStatus.setText("❌ Erreur : " + error);
                            connectionStatus.setTextColor(getResources().getColor(R.color.error, getContext().getTheme()));
                        }
                    });
                    // Remove listener after error
                    wsClient.removeListener(this);
                }
            };
            
            wsClient.addListener(connectionListener);
            
            // Timeout handler
            handler.postDelayed(() -> {
                if (appState != null && !appState.isConnected()) {
                    connectionStatus.setText("⏱️ Timeout : Impossible de se connecter à " + ip);
                    connectionStatus.setTextColor(getResources().getColor(R.color.error, getContext().getTheme()));
                    wsClient.removeListener(connectionListener);
                }
            }, 10000); // 10 second timeout
            
            wsClient.connect(ip);
        }
    }

    private void updateConnectionUI(boolean connected) {
        if (getContext() == null || connectionIcon == null) return;
        
        android.util.Log.d("ConfigFragment", "updateConnectionUI called with connected=" + connected);
        
        int tertiaryColor = getResources().getColor(R.color.tertiary, getContext().getTheme());
        int variantColor = getResources().getColor(R.color.outline_variant, getContext().getTheme());
        int onSurfaceVariant = getResources().getColor(R.color.on_surface_variant, getContext().getTheme());
        int errorColor = getResources().getColor(R.color.error, getContext().getTheme());
        int onError = getResources().getColor(R.color.on_error, getContext().getTheme());
        int onPrimary = getResources().getColor(R.color.on_primary, getContext().getTheme());

        if (connected) {
            android.util.Log.d("ConfigFragment", "Updating UI for CONNECTED state");
            
            // Update icon
            connectionIconContainer.setBackgroundResource(R.drawable.bg_connection_icon_active);
            connectionIcon.setColorFilter(tertiaryColor);
            
            // Update status text
            connectionStatus.setText("Connexion établie");
            connectionStatus.setTextColor(tertiaryColor);

            // Update dots
            dotEndpoint.setBackgroundResource(R.drawable.bg_toggle_on);
            dotJson.setBackgroundResource(R.drawable.bg_toggle_on);
            labelEndpoint.setText("WebSocket connecté");
            labelEndpoint.setTextColor(tertiaryColor);
            labelJson.setTextColor(tertiaryColor);

            // Update button to disconnect style
            btnTestConnection.setText("Se Déconnecter");
            btnTestConnection.setBackgroundResource(R.drawable.bg_btn_danger);
            btnTestConnection.setTextColor(android.graphics.Color.WHITE); // White text on red button
            btnTestConnection.setIcon(getResources().getDrawable(android.R.drawable.ic_delete, getContext().getTheme()));
            btnTestConnection.setIconTint(android.content.res.ColorStateList.valueOf(android.graphics.Color.WHITE));

            // Start wave animation
            android.util.Log.d("ConfigFragment", "Starting wave animation");
            startWaveAnimation();

        } else {
            android.util.Log.d("ConfigFragment", "Updating UI for DISCONNECTED state");
            
            // Update icon
            connectionIconContainer.setBackgroundResource(R.drawable.bg_connection_icon);
            connectionIcon.setColorFilter(variantColor);
            
            // Update status text
            connectionStatus.setText("En attente de connexion...");
            connectionStatus.setTextColor(onSurfaceVariant);

            // Update dots
            dotEndpoint.setBackgroundResource(R.drawable.bg_toggle_off);
            dotJson.setBackgroundResource(R.drawable.bg_toggle_off);
            labelEndpoint.setText("WebSocket déconnecté");
            labelEndpoint.setTextColor(onSurfaceVariant);
            labelJson.setTextColor(onSurfaceVariant);

            // Update button to connect style
            btnTestConnection.setText("Se Connecter");
            btnTestConnection.setBackgroundResource(R.drawable.bg_btn_primary);
            btnTestConnection.setTextColor(android.graphics.Color.WHITE); // White text on primary button
            btnTestConnection.setIcon(getResources().getDrawable(android.R.drawable.ic_menu_manage, getContext().getTheme()));
            btnTestConnection.setIconTint(android.content.res.ColorStateList.valueOf(android.graphics.Color.WHITE));

            // Stop wave animation
            android.util.Log.d("ConfigFragment", "Stopping wave animation");
            stopWaveAnimation();
        }
    }

    private void startWaveAnimation() {
        if (waveContainer == null || getContext() == null) {
            android.util.Log.e("ConfigFragment", "Cannot start wave animation: waveContainer=" + waveContainer + ", context=" + getContext());
            return;
        }
        
        android.util.Log.d("ConfigFragment", "Starting wave animation - clearing existing views");
        waveContainer.removeAllViews();
        waveContainer.setVisibility(View.VISIBLE);

        // Use a more visible color for waves
        int waveColor = getResources().getColor(R.color.primary, getContext().getTheme());
        android.util.Log.d("ConfigFragment", "Wave color: " + Integer.toHexString(waveColor));
        
        // Create 3 wave rings
        for (int i = 0; i < 3; i++) {
            android.util.Log.d("ConfigFragment", "Creating wave ring " + i);
            final View waveRing = new View(getContext());
            FrameLayout.LayoutParams params = new FrameLayout.LayoutParams(80, 80);
            params.gravity = android.view.Gravity.CENTER;
            waveRing.setLayoutParams(params);
            
            // Create gradient drawable for the wave ring
            GradientDrawable drawable = new GradientDrawable();
            drawable.setShape(GradientDrawable.OVAL);
            drawable.setStroke(3, waveColor); // Thicker stroke (3dp instead of 2dp)
            drawable.setAlpha(180); // Semi-transparent
            waveRing.setBackground(drawable);
            
            waveContainer.addView(waveRing);
            android.util.Log.d("ConfigFragment", "Wave ring " + i + " added to container");
            
            // Animate each wave with delay
            final int delay = i * 600; // 600ms delay between each wave
            final int waveIndex = i;
            handler.postDelayed(() -> {
                if (waveRing.getParent() != null) {
                    android.util.Log.d("ConfigFragment", "Starting animation for wave " + waveIndex);
                    animateWave(waveRing);
                } else {
                    android.util.Log.w("ConfigFragment", "Wave " + waveIndex + " has no parent, skipping animation");
                }
            }, delay);
        }
        android.util.Log.d("ConfigFragment", "Wave animation setup complete. Container has " + waveContainer.getChildCount() + " children");
    }

    private void animateWave(View waveRing) {
        if (waveRing == null || getContext() == null || waveRing.getParent() == null) return;

        // Scale animation from 1.0 to 2.5 (expand)
        ObjectAnimator scaleX = ObjectAnimator.ofFloat(waveRing, "scaleX", 1f, 2.5f);
        ObjectAnimator scaleY = ObjectAnimator.ofFloat(waveRing, "scaleY", 1f, 2.5f);
        
        // Fade out animation
        ObjectAnimator alpha = ObjectAnimator.ofFloat(waveRing, "alpha", 0.8f, 0f);

        // Set duration
        scaleX.setDuration(1800);
        scaleY.setDuration(1800);
        alpha.setDuration(1800);

        // Repeat infinitely
        scaleX.setRepeatCount(ValueAnimator.INFINITE);
        scaleY.setRepeatCount(ValueAnimator.INFINITE);
        alpha.setRepeatCount(ValueAnimator.INFINITE);

        // Use linear interpolator for smooth continuous animation
        scaleX.setInterpolator(new LinearInterpolator());
        scaleY.setInterpolator(new LinearInterpolator());
        alpha.setInterpolator(new LinearInterpolator());

        // Start all animations
        scaleX.start();
        scaleY.start();
        alpha.start();

        // Store animators to cancel later
        waveRing.setTag(R.id.connection_icon_container, new ObjectAnimator[]{scaleX, scaleY, alpha});
    }

    private void stopWaveAnimation() {
        if (waveContainer == null) return;
        
        // Cancel all running animations
        for (int i = 0; i < waveContainer.getChildCount(); i++) {
            View child = waveContainer.getChildAt(i);
            ObjectAnimator[] animators = (ObjectAnimator[]) child.getTag(R.id.connection_icon_container);
            if (animators != null) {
                for (ObjectAnimator animator : animators) {
                    if (animator != null) {
                        animator.cancel();
                    }
                }
            }
        }
        
        waveContainer.removeAllViews();
        waveContainer.setVisibility(View.GONE);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        stopWaveAnimation();
    }
}
