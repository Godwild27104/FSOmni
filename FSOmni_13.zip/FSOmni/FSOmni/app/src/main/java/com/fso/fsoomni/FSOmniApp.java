package com.fso.fsoomni;

import android.app.Application;
import android.content.SharedPreferences;

import androidx.appcompat.app.AppCompatDelegate;

import com.fso.fsoomni.model.AppState;
import com.fso.fsoomni.websocket.FSOWebSocketClient;

public class FSOmniApp extends Application {

    public static final String PREFS_NAME = "fsoomni_prefs";
    public static final String KEY_DARK_MODE = "dark_mode";
    public static final String KEY_THEME_TRANSITIONING = "theme_transitioning";

    private static AppState appState;
    private static FSOWebSocketClient wsClient;

    @Override
    public void onCreate() {
        super.onCreate();
        // Apply the persisted theme as early as possible — before any Activity is created.
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean isDark = prefs.getBoolean(KEY_DARK_MODE, false);
        AppCompatDelegate.setDefaultNightMode(
                isDark ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO);
        
        // Initialize AppState and WebSocketClient as singletons
        if (appState == null) {
            appState = new AppState();
        }
        if (wsClient == null) {
            wsClient = new FSOWebSocketClient(appState);
        }
    }

    public static AppState getAppState() {
        return appState;
    }

    public static FSOWebSocketClient getWsClient() {
        return wsClient;
    }
}
