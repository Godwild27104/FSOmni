// ================================================================
// laser_comm.h — Communication Laser OOK (On-Off Keying)
// ================================================================
// Gère la transmission et réception de données par laser sur 3 canaux
// en parallèle avec modulation OOK et timers hardware ESP32.
//
// CORRECTIONS v1.1 :
//   - Cooldown 1 seconde entre fin TX et réactivation RX (millis, non bloquant)
//   - File d'attente (TX queue) pour les messages arrivant pendant TX actif
// ================================================================

#ifndef LASER_COMM_H
#define LASER_COMM_H

#include <Arduino.h>
#include "protocol.h"

// Inclusion des registres GPIO directs pour ESP32
#ifdef ESP32
  #include <soc/gpio_struct.h>
  #include <soc/gpio_reg.h>
  #include <driver/gpio.h>
#endif

// ================================================================
// CONFIGURATION GPIO — ESP32-S3 SAFE PINS
// ================================================================
#define TX1_PIN 4    // GPIO4  — laser TX canal 1
#define TX2_PIN 5    // GPIO5  — laser TX canal 2
#define TX3_PIN 6    // GPIO6  — laser TX canal 3

#define RX1_PIN 7    // GPIO7  — photodiode RX canal 1
#define RX2_PIN 8    // GPIO8  — photodiode RX canal 2
#define RX3_PIN 9    // GPIO9  — photodiode RX canal 3

// ================================================================
// PARAMÈTRES DE COMMUNICATION
// ================================================================
#define BIT_DURATION_US     5000    // 5ms par bit = 200 bits/s par canal
#define NUM_CHANNELS        3       // 3 canaux en parallèle = 600 bits/s total
#define MAX_FRAME_SIZE      4096    // Taille max d'une trame (octets)

// Protocole OOK
#define PREAMBLE_PATTERN    0xAA
#define PREAMBLE_LENGTH     8
#define SYNC_WORD           0x7E
#define FRAME_HEADER        0x02
#define FRAME_FOOTER        0x03
#define ESCAPE_BYTE         0x1B

// OOK direct — digitalWrite HIGH/LOW, pas de PWM
// ledcWrite() n'est pas ISR-safe sur ESP32-S3 Arduino Core 3.x

// ================================================================
// FILE D'ATTENTE TX (TX QUEUE)
// ================================================================
// Stocke les messages qui arrivent pendant qu'une TX est en cours.
// Capacité : 8 messages en attente max.
#define TX_QUEUE_SIZE 8
#define TX_QUEUE_TEXT_MAX 512   // Taille max du texte dans la queue

struct TxQueueEntry {
  char text[TX_QUEUE_TEXT_MAX];
  int  unitId;
  bool valid;
};

TxQueueEntry txQueue[TX_QUEUE_SIZE];
uint8_t txQueueHead = 0;   // Prochain à lire
uint8_t txQueueTail = 0;   // Prochain à écrire
uint8_t txQueueCount = 0;  // Nombre d'entrées actuelles

// Ajouter un message dans la queue
bool txQueuePush(const String& text, int unitId) {
  if (txQueueCount >= TX_QUEUE_SIZE) {
    Serial.println("⚠️  File d'attente TX pleine — message ignoré");
    return false;
  }
  TxQueueEntry& entry = txQueue[txQueueTail];
  strncpy(entry.text, text.c_str(), TX_QUEUE_TEXT_MAX - 1);
  entry.text[TX_QUEUE_TEXT_MAX - 1] = '\0';
  entry.unitId = unitId;
  entry.valid = true;
  txQueueTail = (txQueueTail + 1) % TX_QUEUE_SIZE;
  txQueueCount++;
  Serial.printf("📬 Message mis en file d'attente [%d/%d] : unit_id=%d, text=\"%s\"\n",
                txQueueCount, TX_QUEUE_SIZE, unitId, entry.text);
  return true;
}

// Récupérer le prochain message de la queue (retourne false si vide)
bool txQueuePop(String& text, int& unitId) {
  if (txQueueCount == 0) return false;
  TxQueueEntry& entry = txQueue[txQueueHead];
  text   = String(entry.text);
  unitId = entry.unitId;
  entry.valid = false;
  txQueueHead = (txQueueHead + 1) % TX_QUEUE_SIZE;
  txQueueCount--;
  return true;
}

// ================================================================
// VARIABLES GLOBALES
// ================================================================

const uint8_t txPins[NUM_CHANNELS] = {TX1_PIN, TX2_PIN, TX3_PIN};
const uint8_t rxPins[NUM_CHANNELS] = {RX1_PIN, RX2_PIN, RX3_PIN};

TxState txState;
RxState rxState;

volatile uint8_t  txBuffer[MAX_FRAME_SIZE];
volatile uint16_t txBufferLen    = 0;
volatile uint16_t txBitGroupIndex = 0;
volatile bool     txBusy         = false;
volatile bool     txEnabled      = false;

volatile uint8_t  rxBuffer[MAX_FRAME_SIZE];
volatile uint16_t rxBufferLen       = 0;
volatile uint16_t rxBitGroupIndex   = 0;
volatile bool     rxFrameComplete   = false;
volatile bool     rxPreambleDetected = false;
volatile uint8_t  rxPreambleCount   = 0;
volatile bool     rxEnabled         = true;
volatile bool     preambleJustDetected = false;

hw_timer_t *txTimer = NULL;
hw_timer_t *rxTimer = NULL;

volatile uint32_t txTimerCounter = 0;
volatile uint32_t rxTimerCounter = 0;
#define TIMER_DIVIDER 25

// ================================================================
// COOLDOWN TX → RX
// ================================================================
// Quand TX termine, on attend TX_RX_COOLDOWN_MS avant de réactiver RX.
// Ça laisse le temps au dernier bit d'arriver côté récepteur et évite
// que le RX capte du bruit résiduel juste après la fin du laser.
#define TX_RX_COOLDOWN_MS 1000

volatile bool     txJustFinished    = false;  // Flag posé par l'ISR
uint32_t          txCooldownStart   = 0;      // Timestamp de fin de TX (dans loop)
bool              txInCooldown      = false;  // On est dans la période de garde

String receivedText  = "";
int    receivedUnitId = 0;

// ================================================================
// ISR — TRANSMISSION (Timer 0)
// ================================================================
void IRAM_ATTR onTxTimer() {
  txTimerCounter++;
  if (txTimerCounter < TIMER_DIVIDER) return;
  txTimerCounter = 0;

  if (!txEnabled || !txBusy) return;

  bool allChannelsDone = true;

  for (int ch = 0; ch < NUM_CHANNELS; ch++) {
    uint32_t bitIdx    = txBitGroupIndex * NUM_CHANNELS + ch;
    uint32_t byteIndex = bitIdx / 8;
    uint8_t  bitPos    = bitIdx % 8;

    if (byteIndex >= txBufferLen) {
      // Canal terminé — éteindre via registre direct
      if (txPins[ch] < 32) GPIO.out_w1tc = (1UL << txPins[ch]);
      else                  GPIO.out1_w1tc.val = (1UL << (txPins[ch] - 32));
      continue;
    }

    allChannelsDone = false;

    uint8_t bit = (txBuffer[byteIndex] >> bitPos) & 0x01;

    // OOK via registres GPIO directs — 100% ISR-safe
    if (bit) {
      if (txPins[ch] < 32) GPIO.out_w1ts = (1UL << txPins[ch]);
      else                  GPIO.out1_w1ts.val = (1UL << (txPins[ch] - 32));
    } else {
      if (txPins[ch] < 32) GPIO.out_w1tc = (1UL << txPins[ch]);
      else                  GPIO.out1_w1tc.val = (1UL << (txPins[ch] - 32));
    }
  }

  if (allChannelsDone) {
    // Éteindre tous les canaux via registres directs
    for (int ch = 0; ch < NUM_CHANNELS; ch++) {
      if (txPins[ch] < 32) GPIO.out_w1tc = (1UL << txPins[ch]);
      else                  GPIO.out1_w1tc.val = (1UL << (txPins[ch] - 32));
    }
    txBusy         = false;
    txEnabled      = false;
    txState.active = false;
    txJustFinished = true;
    return;
  }

  txBitGroupIndex++;
}

// ================================================================
// ISR — RÉCEPTION (Timer 1)
// ================================================================
void IRAM_ATTR onRxTimer() {
  rxTimerCounter++;
  if (rxTimerCounter < TIMER_DIVIDER) return;
  rxTimerCounter = 0;

  if (!rxEnabled)       return;
  if (rxFrameComplete)  return;

  for (int ch = 0; ch < NUM_CHANNELS; ch++) {
    uint32_t bitIdx  = rxBitGroupIndex * NUM_CHANNELS + ch;
    uint32_t byteIndex = bitIdx / 8;
    uint8_t  bitPos    = bitIdx % 8;

    if (byteIndex >= MAX_FRAME_SIZE) {
      rxFrameComplete = true;
      rxState.errorCount++;
      return;
    }

    uint8_t bit = digitalRead(rxPins[ch]) ? 1 : 0;
    if (bit) rxBuffer[byteIndex] |=  (1 << bitPos);
    else     rxBuffer[byteIndex] &= ~(1 << bitPos);
  }

  rxBitGroupIndex++;

  // Détection du préambule
  if (!rxPreambleDetected) {
    if (rxBitGroupIndex >= 8) {
      uint8_t preambleMatches = 0;
      for (int i = 0; i < PREAMBLE_LENGTH; i++) {
        if (rxBuffer[i] == PREAMBLE_PATTERN) preambleMatches++;
      }
      if (preambleMatches >= 6) {
        rxPreambleDetected   = true;
        preambleJustDetected = true;
      } else {
        rxBitGroupIndex = 0;
        memset((void*)rxBuffer, 0, 64);  // Reset 64 octets : couvre préambule + sync + header
        return;
      }
    } else {
      return;
    }
  }

  // Détection du footer
  if (rxBitGroupIndex > 96) {
    uint32_t lastByteIdx = (rxBitGroupIndex * NUM_CHANNELS) / 8;
    if (lastByteIdx > 0 && lastByteIdx < MAX_FRAME_SIZE) {
      if (rxBuffer[lastByteIdx - 1] == FRAME_FOOTER) {
        rxFrameComplete = true;
        rxBufferLen     = lastByteIdx;
      }
    }
  }

  if (rxBitGroupIndex > 11000) {  // 4096 octets × 8 bits / 3 canaux = 10923 groupes max
    rxFrameComplete = true;
    rxBufferLen     = 0;
  }
}

// ================================================================
// INITIALISATION
// ================================================================
void initLaserComm() {
  Serial.println("Initialisation de la communication laser OOK...");

  // GPIO TX — sortie numérique simple (OOK : HIGH = laser ON, LOW = laser OFF)
  for (int ch = 0; ch < NUM_CHANNELS; ch++) {
    pinMode(txPins[ch], OUTPUT);
    digitalWrite(txPins[ch], LOW);  // Laser éteint par défaut
    Serial.printf("  TX Canal %d : GPIO %d (OUTPUT)\n", ch + 1, txPins[ch]);
  }

  for (int ch = 0; ch < NUM_CHANNELS; ch++) {
    pinMode(rxPins[ch], INPUT_PULLUP);
    Serial.printf("  RX Canal %d : GPIO %d (INPUT_PULLUP)\n", ch + 1, rxPins[ch]);
  }

  // Initialiser la queue TX
  memset(txQueue, 0, sizeof(txQueue));
  txQueueHead = txQueueTail = txQueueCount = 0;
  Serial.printf("  ✅ File d'attente TX initialisée (%d slots)\n", TX_QUEUE_SIZE);

  uint32_t timerFrequency = 5000;

  txTimer = timerBegin(timerFrequency);
  if (!txTimer) { Serial.println("  ❌ ERREUR : Impossible de créer txTimer"); return; }
  timerAttachInterrupt(txTimer, &onTxTimer);
  timerStart(txTimer);  // CRITIQUE : démarrer le timer !
  Serial.println("  ✅ Timer TX créé et démarré (5000 Hz → 200 Hz avec diviseur)");

  rxTimer = timerBegin(timerFrequency);
  if (!rxTimer) { Serial.println("  ❌ ERREUR : Impossible de créer rxTimer"); return; }
  timerAttachInterrupt(rxTimer, &onRxTimer);
  timerStart(rxTimer);  // CRITIQUE : démarrer le timer !
  Serial.println("  ✅ Timer RX créé et démarré (5000 Hz → 200 Hz avec diviseur)");

  Serial.printf("Communication laser initialisée (3 canaux, %d bits/s total)\n",
                (1000000 / BIT_DURATION_US) * NUM_CHANNELS);
}

// ================================================================
// TRANSMISSION DE TEXTE (interne — appelée aussi par la queue)
// ================================================================
bool _doTransmit(const String& text, int unitId) {
  String payload;
  payload = (unitId > 0) ? String(unitId) + ":" + text : "0:" + text;

  Serial.printf("📡 Préparation transmission : unit_id=%d, text=\"%s\"\n", unitId, text.c_str());
  Serial.printf("   Payload laser : \"%s\" (%d octets)\n", payload.c_str(), payload.length());

  uint16_t estimatedSize = 11 + payload.length() + (payload.length() / 10);
  if (estimatedSize > MAX_FRAME_SIZE) {
    Serial.printf("❌ Message trop long (%d octets, max %d)\n", estimatedSize, MAX_FRAME_SIZE);
    return false;
  }
  if (!txTimer) { Serial.println("❌ ERREUR : txTimer non initialisé"); return false; }

  uint16_t framePos = 0;
  for (int i = 0; i < PREAMBLE_LENGTH; i++) txBuffer[framePos++] = PREAMBLE_PATTERN;
  txBuffer[framePos++] = SYNC_WORD;
  txBuffer[framePos++] = FRAME_HEADER;

  for (unsigned int i = 0; i < payload.length(); i++) {
    uint8_t b = payload[i];
    if (b == FRAME_HEADER || b == FRAME_FOOTER || b == ESCAPE_BYTE) txBuffer[framePos++] = ESCAPE_BYTE;
    txBuffer[framePos++] = b;
    if (framePos >= MAX_FRAME_SIZE - 2) { Serial.println("❌ Message trop long"); return false; }
  }
  txBuffer[framePos++] = FRAME_FOOTER;
  txBufferLen = framePos;

  Serial.printf("   Trame construite : %d octets (préambule + header + payload + footer)\n", txBufferLen);

  // Suspendre RX
  rxEnabled = false;
  Serial.println("  ⏸️ RX pausé pendant TX");

  txBitGroupIndex = 0;
  txTimerCounter  = 0;
  txBusy          = true;
  txState.active  = true;
  txState.totalBytes = txBufferLen;
  txState.sentBytes  = 0;
  txState.startTime  = millis();
  txEnabled       = true;

  Serial.println("  ✅ Transmission démarrée");
  return true;
}

// ================================================================
// TRANSMISSION PUBLIQUE — gère la queue automatiquement
// ================================================================
bool transmitText(const String& text, int unitId) {
  if (txBusy || txInCooldown) {
    // TX occupée ou en cooldown : mettre en file d'attente
    Serial.printf("⏳ TX occupée (cooldown=%d) — mise en file : \"%s\"\n",
                  txInCooldown ? 1 : 0, text.c_str());
    return txQueuePush(text, unitId);
  }
  return _doTransmit(text, unitId);
}

// ================================================================
// DÉMARRAGE DE LA RÉCEPTION
// ================================================================
void startReceiving() {
  Serial.println("👂 Démarrage de la réception laser...");
  if (!rxTimer) { Serial.println("  ❌ ERREUR : rxTimer non initialisé"); return; }

  memset((void*)rxBuffer, 0, MAX_FRAME_SIZE);
  rxBufferLen          = 0;
  rxBitGroupIndex      = 0;
  rxFrameComplete      = false;
  rxPreambleDetected   = false;
  rxState.active       = true;
  rxState.startTime    = millis();
  rxEnabled            = true;

  Serial.println("  ✅ Réception active (attente du préambule)");
}

void stopReceiving() {
  timerStop(rxTimer);
  rxState.active = false;
  Serial.println("🛑 Réception laser arrêtée");
}

// ================================================================
// TRAITEMENT DE LA TRAME REÇUE
// ================================================================
void processReceivedFrame() {
  Serial.printf("📥 Traitement de la trame reçue (%d octets)\n", rxBufferLen);

  int headerPos = -1;
  for (int i = 0; i < rxBufferLen; i++) {
    if (rxBuffer[i] == FRAME_HEADER) { headerPos = i; break; }
  }
  if (headerPos == -1) { Serial.println("❌ Pas de FRAME_HEADER trouvé"); return; }

  int footerPos = -1;
  for (int i = headerPos + 1; i < rxBufferLen; i++) {
    if (rxBuffer[i] == FRAME_FOOTER) { footerPos = i; break; }
  }
  if (footerPos == -1) { Serial.println("❌ Pas de FRAME_FOOTER trouvé"); return; }

  String decoded = "";
  bool escaped = false;
  for (int i = headerPos + 1; i < footerPos; i++) {
    uint8_t b = rxBuffer[i];
    if (escaped)            { decoded += (char)b; escaped = false; }
    else if (b == ESCAPE_BYTE) { escaped = true; }
    else                    { decoded += (char)b; }
  }

  Serial.printf("  ✅ Payload décodé : \"%s\"\n", decoded.c_str());

  int colonPos = decoded.indexOf(':');
  if (colonPos > 0) {
    receivedUnitId = decoded.substring(0, colonPos).toInt();
    receivedText   = decoded.substring(colonPos + 1);
    Serial.printf("  ✅ unit_id=%d, text=\"%s\"\n", receivedUnitId, receivedText.c_str());
  } else {
    receivedUnitId = 0;
    receivedText   = decoded;
    Serial.printf("  ⚠️ Format sans unit_id, text=\"%s\"\n", receivedText.c_str());
  }

  rxState.receivedBytes = receivedText.length();
}

void stopAllLasers() {
  for (int ch = 0; ch < NUM_CHANNELS; ch++) digitalWrite(txPins[ch], LOW);
}

// ================================================================
// BOUCLE DE MAINTENANCE — appelée depuis loop()
// ================================================================
void laserCommLoop() {

  // Log préambule (déplacé hors ISR)
  if (preambleJustDetected) {
    preambleJustDetected = false;
    Serial.println("   🎯 Préambule détecté - Enregistrement activé");
  }

  // ----------------------------------------------------------
  // 1. L'ISR vient de terminer une TX → démarrer le cooldown
  // ----------------------------------------------------------
  if (txJustFinished) {
    txJustFinished    = false;
    txInCooldown      = true;
    txCooldownStart   = millis();

    uint32_t duration = millis() - txState.startTime;
    txState.bitRate   = (txBufferLen * 8 * 1000.0) / duration;
    Serial.printf("✅ Transmission terminée en %u ms (débit: %.1f bits/s)\n",
                  duration, txState.bitRate);
    Serial.printf("⏱️  Cooldown TX→RX : attente %d ms avant de réactiver RX...\n",
                  TX_RX_COOLDOWN_MS);
  }

  // ----------------------------------------------------------
  // 2. Cooldown écoulé → réactiver RX (et vider la queue si besoin)
  // ----------------------------------------------------------
  if (txInCooldown && (millis() - txCooldownStart >= TX_RX_COOLDOWN_MS)) {
    txInCooldown = false;

    // Y a-t-il des messages en attente dans la queue ?
    if (txQueueCount > 0) {
      String  nextText;
      int     nextUnitId;
      txQueuePop(nextText, nextUnitId);
      Serial.printf("📤 Envoi du prochain message de la queue (%d restant(s)) : \"%s\"\n",
                    txQueueCount, nextText.c_str());
      _doTransmit(nextText, nextUnitId);
      // RX sera réactivé après CETTE transmission (prochain cycle de cooldown)
    } else {
      // Aucun message en attente → on réactive RX maintenant
      rxPreambleDetected = false;
      rxBitGroupIndex    = 0;
      rxTimerCounter     = 0;
      rxFrameComplete    = false;
      memset((void*)rxBuffer, 0, 64);  // Reset 64 octets : couvre préambule + sync + header
      rxState.startTime  = millis();
      rxState.active     = true;
      rxEnabled          = true;
      Serial.println("  ▶️ RX réactivé après cooldown TX (aucun message en attente)");
    }
  }

  // ----------------------------------------------------------
  // 3. Trame RX complète reçue → traiter
  // ----------------------------------------------------------
  if (rxFrameComplete) {
    rxEnabled = false;

    uint32_t duration  = millis() - rxState.startTime;
    rxState.bitRate    = (rxBufferLen * 8 * 1000.0) / duration;
    Serial.printf("✅ Réception terminée en %u ms (débit: %.1f bits/s)\n",
                  duration, rxState.bitRate);

    if (rxBufferLen > 0) processReceivedFrame();

    // Réinitialiser pour la prochaine trame
    rxFrameComplete      = false;
    rxPreambleDetected   = false;
    rxBitGroupIndex      = 0;
    rxTimerCounter       = 0;
    memset((void*)rxBuffer, 0, MAX_FRAME_SIZE);
    rxState.startTime    = millis();
    rxState.active       = true;
    rxEnabled            = true;
  }
}

#endif
