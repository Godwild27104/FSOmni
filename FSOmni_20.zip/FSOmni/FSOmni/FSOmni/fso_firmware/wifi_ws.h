// ================================================================
// wifi_ws.h — Gestion WiFi et WebSocket
// ================================================================
//
// CORRECTIONS v1.1 :
//   - transmitText() retourne maintenant true si le message est mis
//     en file d'attente (plus d'erreur "Transmission déjà en cours")
//   - Réponse WS "tx_queued" quand le message est mis en attente
// ================================================================

#ifndef WIFI_WS_H
#define WIFI_WS_H

#include <WiFi.h>
#include <AsyncTCP.h>
#include <ESPAsyncWebServer.h>
#include <ArduinoJson.h>
#include "config.h"
#include "protocol.h"
#include "laser_comm.h"

AsyncWebServer server(WS_PORT);
AsyncWebSocket ws("/");

// ================================================================
// Gestionnaire d'événements WebSocket
// ================================================================
void onWsEvent(AsyncWebSocket *server, AsyncWebSocketClient *client,
               AwsEventType type, void *arg, uint8_t *data, size_t len) {

  switch(type) {

    case WS_EVT_CONNECT:
      Serial.printf("✅ Client WebSocket connecté [ID: %u] depuis %s\n",
                    client->id(), client->remoteIP().toString().c_str());
      {
        StaticJsonDocument<256> doc;
        doc["type"]             = "connected";
        doc["message"]          = "Bienvenue sur ESP32 FSOmni";
        doc["device"]           = "ESP32-S3";
        doc["firmware_version"] = "1.1.0";
        String s; serializeJson(doc, s);
        client->text(s);
        Serial.printf("📤 Message de bienvenue envoyé : %s\n", s.c_str());
      }
      {
        StaticJsonDocument<512> tel;
        tel["type"]               = "telemetry";
        tel["throughput"]         = 9.8;
        tel["ber"]                = 1.2e-9;
        tel["rssi"]               = -42.0;
        tel["alignment_precision"]= 90.0;
        String s; serializeJson(tel, s);
        client->text(s);
        Serial.printf("📤 Télémétrie initiale envoyée : %s\n", s.c_str());
      }
      break;

    case WS_EVT_DISCONNECT:
      Serial.printf("🔌 Client WebSocket déconnecté [ID: %u]\n", client->id());
      break;

    case WS_EVT_DATA:
      {
        AwsFrameInfo *info = (AwsFrameInfo*)arg;
        if (info->final && info->index == 0 && info->len == len) {
          if (info->opcode == WS_TEXT) {
            data[len] = 0;
            String message = String((char*)data);
            Serial.printf("📩 Message reçu du client [ID: %u] : %s\n",
                          client->id(), message.c_str());

            StaticJsonDocument<1024> doc;  // 1024 pour supporter les messages jusqu'à ~512 octets
            DeserializationError error = deserializeJson(doc, message);

            if (!error) {
              // ── Type numérique (protocole ÉTAPE 2) ──────────────────
              if (doc["type"].is<int>()) {
                int typeNum = doc["type"];

                if (typeNum == MSG_TEXT_MESSAGE) {
                  const char* text = doc["text"];
                  int unitId = doc.containsKey("unit_id") ? doc["unit_id"].as<int>() : 0;

                  Serial.printf("   → Message texte à transmettre : unit_id=%d, text=\"%s\"\n",
                                unitId, text);

                  bool queued = false;
                  bool ok     = false;

                  if (txBusy || txInCooldown) {
                    // TX occupée → mettre en file
                    ok     = txQueuePush(String(text), unitId);
                    queued = ok;
                  } else {
                    ok = _doTransmit(String(text), unitId);
                  }

                  if (ok) {
                    if (queued) {
                      // Informer l'app que le message est en file d'attente
                      StaticJsonDocument<128> resp;
                      resp["type"]     = MSG_TX_PROGRESS;
                      resp["status"]   = "tx_queued";
                      resp["queue_len"]= txQueueCount;
                      String s; serializeJson(resp, s);
                      client->text(s);
                      Serial.printf("   📬 tx_queued envoyé, file=%d\n", txQueueCount);
                    } else {
                      client->text("{\"type\":10,\"status\":\"tx_started\"}");
                    }
                  } else {
                    client->text(createErrorJson("File d'attente TX pleine"));
                    Serial.println("   ❌ File d'attente TX pleine");
                  }
                }
                else if (typeNum == MSG_PING) {
                  String pong = createPongJson();
                  client->text(pong);
                  Serial.printf("   → PONG envoyé : %s\n", pong.c_str());
                }
              }
              // ── Type string (compatibilité ÉTAPE 1) ─────────────────
              else if (doc["type"].is<const char*>()) {
                const char* msgType = doc["type"];
                Serial.printf("   Type de message : %s\n", msgType);

                if (strcmp(msgType, "ping") == 0) {
                  client->text("{\"type\":\"pong\",\"timestamp\":" + String(millis()) + "}");
                }
                else if (strcmp(msgType, "servo") == 0) {
                  Serial.println("   → Commande servo reçue");
                }
                else if (strcmp(msgType, "auto_align") == 0) {
                  Serial.println("   → Commande auto-align reçue");
                }
              }
              else {
                Serial.println("   ❌ Champ 'type' manquant ou format invalide");
              }
            } else {
              Serial.printf("   ❌ Erreur parsing JSON : %s\n", error.c_str());
            }
          }
        }
      }
      break;

    case WS_EVT_PONG:
      Serial.printf("🏓 Pong reçu du client [ID: %u]\n", client->id());
      break;

    case WS_EVT_ERROR:
      Serial.printf("❌ Erreur WebSocket client [ID: %u]\n", client->id());
      break;
  }
}

// ================================================================
// Initialisation WiFi et WebSocket
// ================================================================
void initWifiWs() {
  Serial.println("Configuration du point d'accès WiFi...");

  WiFi.mode(WIFI_AP);
  WiFi.softAP(WIFI_SSID, WIFI_PASSWORD, WIFI_CHANNEL, 0, MAX_CLIENTS);

  IPAddress IP = WiFi.softAPIP();
  Serial.print("Point d'accès WiFi démarré : "); Serial.println(WIFI_SSID);
  Serial.print("Mot de passe : ");               Serial.println(WIFI_PASSWORD);
  Serial.print("Adresse IP : ");                  Serial.println(IP);

  ws.onEvent(onWsEvent);
  server.addHandler(&ws);

  server.on("/", HTTP_GET, [](AsyncWebServerRequest *request){
    request->send(200, "text/html",
      "<html><body>"
      "<h1>ESP32 FSOmni</h1>"
      "<p>Serveur WebSocket actif sur ws://" + WiFi.softAPIP().toString() + ":8080/</p>"
      "<p>Connectez-vous avec l'application Android FSOmni</p>"
      "</body></html>");
  });

  server.begin();
  Serial.println("Serveur WebSocket démarré sur le port 8080");
  Serial.println("Chemin WebSocket : ws://192.168.4.1:8080/");
  Serial.println("En attente de connexions...");
}

// ================================================================
// Boucle de maintenance WiFi/WebSocket
// ================================================================
void wifiWsLoop() {
  ws.cleanupClients();

  // Broadcaster les messages reçus par laser vers les clients WS
  if (!receivedText.isEmpty()) {
    StaticJsonDocument<512> doc;
    doc["type"]   = MSG_TEXT_MESSAGE;
    doc["text"]   = receivedText;
    doc["length"] = receivedText.length();
    if (receivedUnitId > 0) doc["unit_id"] = receivedUnitId;

    String jsonMsg; serializeJson(doc, jsonMsg);
    ws.textAll(jsonMsg);

    Serial.printf("📤 Message laser diffusé aux clients : %s\n", jsonMsg.c_str());

    receivedText   = "";
    receivedUnitId = 0;
  }
}

#endif
