package com.fso.fsoomni.fragment;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.fso.fsoomni.R;
import com.fso.fsoomni.adapter.ChatMessageAdapter;
import com.fso.fsoomni.model.AppState;
import com.fso.fsoomni.model.ChatMessage;
import com.fso.fsoomni.view.WaveformView;
import com.fso.fsoomni.websocket.FSOWebSocketClient;

public class TransferFragment extends Fragment {

    private AppState appState;
    private FSOWebSocketClient wsClient;
    private Handler handler = new Handler(Looper.getMainLooper());

    private RecyclerView chatMessages;
    private ChatMessageAdapter chatAdapter;
    private EditText chatInput;
    private ImageButton btnMic;
    private ImageButton btnSend;
    private LinearLayout voiceBar;
    private WaveformView waveform;
    private TextView voiceTimer;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getActivity() != null) {
            appState = ((com.fso.fsoomni.activity.MainActivity) getActivity()).getAppState();
            wsClient = ((com.fso.fsoomni.activity.MainActivity) getActivity()).getWsClient();
            
            // ================================================================
            // ÉTAPE 2 : Écouter les messages laser (type 2)
            // ================================================================
            if (wsClient != null) {
                wsClient.addListener("2", new com.fso.fsoomni.websocket.FSOWebSocketClient.WebSocketListener() {
                    @Override
                    public void onMessage(String type, com.google.gson.JsonObject data) {
                        // Message laser reçu
                        if (data.has("text")) {
                            String receivedText = data.get("text").getAsString();
                            
                            // Extraire le unit_id (si présent)
                            String senderName;
                            if (data.has("unit_id")) {
                                int unitId = data.get("unit_id").getAsInt();
                                if (unitId > 0) {
                                    senderName = "Unité " + unitId;
                                } else {
                                    senderName = "Inconnu";  // unit_id = 0
                                }
                            } else {
                                senderName = "Inconnu";  // Pas de champ unit_id dans le JSON
                            }
                            
                            // Afficher dans le chat sur le thread UI
                            final String finalSenderName = senderName;
                            handler.post(() -> {
                                java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("HH:mm");
                                String time = sdf.format(new java.util.Date());
                                
                                ChatMessage msg = new ChatMessage(
                                    ChatMessage.MessageType.INCOMING,
                                    finalSenderName,  // ← "Unité X" ou "Inconnu"
                                    receivedText,
                                    time
                                );
                                
                                if (chatAdapter != null) {
                                    chatAdapter.addMessage(msg);
                                    if (chatMessages != null) {
                                        chatMessages.scrollToPosition(chatAdapter.getItemCount() - 1);
                                    }
                                }
                            });
                        }
                    }

                    @Override
                    public void onConnected() {}

                    @Override
                    public void onDisconnected() {}

                    @Override
                    public void onError(String error) {
                        handler.post(() -> {
                            if (getContext() != null) {
                                android.widget.Toast.makeText(getContext(), 
                                    "Erreur laser : " + error, 
                                    android.widget.Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                });
            }
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_transfer, container, false);

        chatMessages = view.findViewById(R.id.chat_messages);
        chatInput = view.findViewById(R.id.chat_input);
        btnMic = view.findViewById(R.id.btn_mic);
        btnSend = view.findViewById(R.id.btn_send);
        voiceBar = view.findViewById(R.id.voice_bar);
        waveform = view.findViewById(R.id.waveform);
        voiceTimer = view.findViewById(R.id.voice_timer);

        // Setup RecyclerView
        chatMessages.setLayoutManager(new LinearLayoutManager(requireContext()));
        chatAdapter = new ChatMessageAdapter(requireContext());
        chatMessages.setAdapter(chatAdapter);

        // ÉTAPE 2 : Pas de messages initiaux, seulement les vrais messages laser
        // Les messages s'afficheront au fur et à mesure de la communication

        // Text input listener
        chatInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 0) {
                    btnMic.setVisibility(View.GONE);
                    btnSend.setVisibility(View.VISIBLE);
                } else {
                    btnMic.setVisibility(View.VISIBLE);
                    btnSend.setVisibility(View.GONE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Send button
        btnSend.setOnClickListener(v -> sendMessage());

        // Mic button - show voice bar
        btnMic.setOnClickListener(v -> {
            voiceBar.setVisibility(View.VISIBLE);
            waveform.startAnimation();
            voiceTimer.setText("0:00");
        });

        // Mic recording button - stop recording
        view.findViewById(R.id.btn_mic_recording).setOnClickListener(v -> {
            voiceBar.setVisibility(View.GONE);
            waveform.stopAnimation();
        });

        // Upload zone
        view.findViewById(R.id.upload_zone).setOnClickListener(v -> {
            // In a real app, this would open a file picker
            // For now, we just show a visual feedback
        });

        // Transmit button
        view.findViewById(R.id.btn_transmit).setOnClickListener(v -> {
            // Send file transmission command
            if (wsClient != null) {
                com.google.gson.JsonObject payload = new com.google.gson.JsonObject();
                payload.addProperty("name", "test.bin");
                payload.addProperty("size", 1024);
                payload.addProperty("chunks", 1);
                wsClient.sendMessage("file_tx_start", payload);
            }
        });

        return view;
    }

    private void sendMessage() {
        String text = chatInput.getText().toString().trim();
        if (text.isEmpty()) return;

        // ================================================================
        // ÉTAPE 2 : Vérifier la longueur du message
        // ================================================================
        int myUnitId = appState.getMyUnitId();
        String unitIdPrefix = myUnitId > 0 ? (myUnitId + ":") : "0:";
        int totalPayloadSize = unitIdPrefix.length() + text.length();
        
        // Limite : MAX_FRAME_SIZE(4096) - préambule(8) - sync(1) - header(1) - footer(1) - marge(50) = ~4035
        // Pour un message texte, on limite à 4000 caractères pour être sûr
        if (totalPayloadSize > 4000) {
            if (getContext() != null) {
                android.widget.Toast.makeText(getContext(), 
                    "Message trop long (" + text.length() + " caractères, max 4000)", 
                    android.widget.Toast.LENGTH_SHORT).show();
            }
            return;
        }

        // Get current time
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("HH:mm");
        String time = sdf.format(new java.util.Date());

        // Récupérer mon unit_id pour l'affichage
        String myName = (myUnitId > 0) ? "Unité " + myUnitId : "Inconnu";

        // Add outgoing message avec mon nom d'unité
        ChatMessage msg = new ChatMessage(ChatMessage.MessageType.OUTGOING, myName, text, time);
        chatAdapter.addMessage(msg);
        chatMessages.scrollToPosition(chatAdapter.getItemCount() - 1);

        // ================================================================
        // ÉTAPE 2 : Envoyer via le protocole laser (type 2)
        // ================================================================
        if (wsClient != null) {
            wsClient.sendTextMessage(text);  // Utilise le nouveau protocole laser
        }

        // Clear input
        chatInput.setText("");
    }

    @Override
    public void onPause() {
        super.onPause();
        if (waveform != null) {
            waveform.stopAnimation();
        }
    }
}
